// create the ML Pipelines
var preprocessingStandardScaler = SklearnPipe.make({
  "name": "standardScaler",
  "technique": SklearnTechnique.make({
    "name": "preprocessing.StandardScaler",
    "processingFunctionName": "transform"
  })
});

var logisticRegression = SklearnPipe.make({
  "name": "logisticRegression",
  "technique": SklearnTechnique.make({
    "name": "linear_model.LogisticRegression",
    "processingFunctionName": "predict_proba",
    "hyperParameters": {"random_state": 42}
  })
});

var accuracyMetric = MLAccuracyMetric.make();

var mlsp = MLSerialPipeline.make({
  "id" : "logisticRegressionMR",
  "name" : "Failure Window Logistic Regression for MapReduce",
  "steps" : [
    MLDatasetDatasetStep.make({
      "name": "preprocess",
      "pipe": preprocessingStandardScaler
    }),
    MLDatasetDatasetStep.make({
      "name": "classifier",
      "pipe": logisticRegression
    })
  ],
  "scoringMetrics" : MLScoringMetric.toScoringMetricMap([accuracyMetric])
});
mlsp.remove();
mlsp.upsert();

// this map function is written knowing that the batch size will
// be 1. It won't work properly if there are more than 1 object in objs
var mapFunction = function(batch, objs, job) {
  var features = job.context.features;
  features.push(job.context.target);
  var spec = {
    start: job.context.start,
    end: job.context.end,
    interval: job.context.interval,
    ids: [objs[0].id],
    expressions : job.context.features
  };
  var emr = SmartBulb.evalMetrics(spec);
  var manufacturer = objs[0].manufacturer.id;
  var result = {};
  result[manufacturer] = Dataset.fromEvalMetricsResult(emr);
  return result;
}

var reduceFunction =  function(outKey, interValues, job){
  var trainingDataset = Dataset.concatenateDatasets(interValues);

  // train
  var trainedModel = job.context.model.train(
    trainingDataset.extractColumns(job.context.features),
    trainingDataset.extractColumns([job.context.target])
  );

  // upsert model after changing name to include manufacturer name
  trainedModel = MLDatasetDatasetSerialPipeline.make(trainedModel).putFields({
    id: job.context.model.id + '_' + outKey,
    name: job.context.model.name + ' - ' + outKey
  });
  trainedModel.remove();
  trainedModel.upsert();
}

var spec = JSMapReduceSpec.make({
  targetType: {typeName: "SmartBulb"},
  include: "id, manufacturer.id",
  map: mapFunction,
  reduce: reduceFunction,
  batchSize: 1,
  context: MLTrainingJobSpecTemp.make({
    start: new DateTime(2011, 1, 1),
    end: new DateTime(2015, 1, 1),
    interval: "DAY",
    target: "WillFailNextMonth",
    features: [
      "DurationOnInHours",
      "StandardDeviationWattsPreviousWeek",
      "SwitchCountPreviousWeek"
      ],
    model: MLSerialPipeline.get(
      "logisticRegressionMR",
      "id, name, steps, features"
    )
  }),
  doNotAbortOnError: true
});

job = JS.mapReduce(spec);
