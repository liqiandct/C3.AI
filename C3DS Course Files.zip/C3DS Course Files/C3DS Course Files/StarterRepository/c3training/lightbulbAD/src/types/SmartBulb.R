pearsonCorrelationR <- function(doubleArray1, doubleArray2){

    res <- cor.test(doubleArray1, doubleArray2,
                        method = "pearson")

    corr <- res$estimate[[1]]

    return(corr)
}