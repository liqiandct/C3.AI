import pandas as pd
import datetime as dt
import numpy as np

def ISO_8601_strdate_to_datetime(str_date):
    return dt.datetime.strptime(str_date[:-6], "%Y-%m-%dT%H:%M:%S")

def abs_day_diff(date_1_str, date_2_str):
    date_1 = ISO_8601_strdate_to_datetime(date_1_str)
    date_2 = ISO_8601_strdate_to_datetime(date_2_str)
    return abs((date_1 - date_2).days) / 365.

def lifeSpanInYearsPythonMethod(bulbId):
    #Get startDate from SmartBulb
    bulb = c3.SmartBulb.get(this={'id': bulbId})
    startDate = bulb.startDate

    #Get endDate from SmartBulbMeasurement
    limitSpec = -1
    defectFilter = "status == 1 && lumens == 0 && parent.id == '" + 'SBMS_serialNo_' + bulb.id + "'"
    smartbulbmeasurement_objs = c3.SmartBulbMeasurement.fetch(spec={'limit':limitSpec,
                                              'filter':defectFilter})["objs"]
    smartbulbmeasurement_pd = pd.DataFrame(smartbulbmeasurement_objs.toJson())
    smartbulbmeasurement_pd.drop(["version"], axis=1, inplace=True)
    smartbulbmeasurement_pd.sort_values(by='end',ascending=False)
    endDate = str(smartbulbmeasurement_pd[['end']].iloc[0].values[0])

    return abs_day_diff(startDate, endDate)

def computeMetricStats(spec):
    # evaluate the metric: evalMetric returns a Timeseries object
    ts = c3.SmartBulb.evalMetric(spec=spec)

    # we access the data of the Timeseries with the field m_data
    data = np.array(ts.m_data)

    # we compute the quartiles and the median in one shot
    p25, p50, p75 = np.percentile(data, [25, 50, 75])
    stats = {
        'min': np.min(data),
        'max': np.max(data),
        'avg': np.mean(data),
        'stddev': np.std(data),
        'p25': p25,
        'median': p50,
        'p75': p75,
        'missingRatio': np.mean(ts.m_missing)  # for the missing ratio, we use the field m_missing
    }
    return stats