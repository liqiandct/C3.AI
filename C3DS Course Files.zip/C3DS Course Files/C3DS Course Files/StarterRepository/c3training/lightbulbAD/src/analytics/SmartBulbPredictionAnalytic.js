/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */
function loadContextAll(){
  var classifier = MLSerialPipeline.fetch({
    order: "descending(meta.updated)",
    limit: 1
  })

  if (classifier.count == 0){
    throw new Error("No trained model is available in this tenant/tag");
  }

  return classifier.objs[0];
}

function processSource(source, inputs, model) {
  
  var predictionsClass;
  var ds;

  inputs.each(function (input) {
    if (ds === undefined) {
      ds = Dataset.fromDFE(input);
    } else {
      ds = Dataset.concatenateDatasets([ds, Dataset.fromDFE(input)]);
    }
  });

  if (ds !== undefined) {
    predictionsClass = model.process(ds);
  }

  if (predictionsClass !== undefined && predictionsClass.data !== undefined) {
  
    predictionsClass = predictionsClass.extractColumns(['1.0'])

    var preds = SmartBulbPrediction.array();

    _.each(_.zip(predictionsClass.indices['0'], predictionsClass.m_data), function (tuple) {
      var inputTimestamp = tuple[0];
      var probability = tuple[1];

      preds.push(SmartBulbPrediction.make({
        smartBulb : source.id,
        timestamp: inputTimestamp,
        prediction: probability
      }));
    });

    SmartBulbPrediction.mergeBatch(preds);
  }
}
