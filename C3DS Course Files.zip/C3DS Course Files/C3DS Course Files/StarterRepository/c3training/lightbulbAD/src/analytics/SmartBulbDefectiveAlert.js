/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

var log = C3.logger('SmartBulbDefectiveAlert');

var FAILED = 1;

function process(input) {
  var data = input.defective.data();
  var dates = input.defective.dates();
  for (var i = 0; i < data.length; i++) {
    // If defective is 1 then we need to update the source object
    if (data.at(i) == FAILED) {
      return SmartBulbEvent.make({
        smartBulb: input.source,
        eventCode: 'DEFECTIVE',
        eventType: 'HEALTH',
        start: dates.at(i),
        end: dates.at(i + 1),
      });
    }
  }
}
