/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

function setupEventMetricTest(spec) {
  var generateSmartBulb = function (idNum) {
    return {
      id: 'SmartBulb-' + idNum,
    };
  };

  // Set up fundamental, shared variables
  var ctx = spec.context || this.createContext(spec.filename, null, [AnalyticsQueue]);
  var eventsStartDate = spec.startDate || DateTime.now().plusYears(-6).toDateMidnight();
  var eventsEndDate = spec.endDate || eventsStartDate.plusHours(spec.numberOfEventsPerBulb);

  // Set up the smart bulbs to be measured
  var smartBulbs = _.times(spec.numberOfBulbs, generateSmartBulb);

  // Set up the events
  var smartBulbEvents = {};
  _.each(smartBulbs, function (smartBulb) {
    smartBulbEvents[smartBulb.id] = _.times(spec.numberOfEventsPerBulb, function (eventIndex) {
      return {
        start: eventsStartDate.plusHours(eventIndex),
        end: eventsStartDate.plusHours(eventIndex + 1),
        eventCode: spec.eventCode,
        eventType: spec.eventType,
        smartBulb: smartBulb,
      };
    }, this);
  }, this);

  // Create the entities to test
  this.upsertBatchEntity(ctx, 'SmartBulb', smartBulbs);
  _.each(_.keys(smartBulbEvents), function (eventKey) {
    this.upsertBatchEntity(ctx, 'SmartBulbEvent', smartBulbEvents[eventKey]);
  }, this);

  // Wait for setup to complete
  this.waitForSetup(ctx, null, 1, 120);

  return {
    context: ctx,
    smartBulbs: smartBulbs,
    smartBulbEvents: smartBulbEvents,
    start: eventsStartDate,
    end: eventsEndDate,
  };
}
