/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

var filename = 'test_SwitchCount';

describe(filename, function () {
  // Set up any necessary data before running any tests
  beforeAll(function () {
    // Set up fundamental, shared variables
    this.ctx = TestApi.createContext(filename, null, [AnalyticsQueue]);
    this.numTestSmartBulbs = 3;
    this.statusChangesStartDate = DateTime.now().plusYears(-1).toDateMidnight();

    // Set up the smart bulbs to be measured
    this.smartBulbs = _.times(this.numTestSmartBulbs, function (index) {
      return { id: 'SmartBulb' + index };
    });

    this.bulbMeasurementSeries = _.times(this.numTestSmartBulbs, function (index) {
      return {
        smartBulb: this.smartBulbs[index],
        interval: 'HOUR',
      };
    }, this);

    // Create the entities to test
    TestApi.upsertBatchEntity(this.ctx, 'SmartBulb', this.smartBulbs);
    this.bulbMeasurementSeriesIds = TestApi.upsertBatchEntity(this.ctx,
      'SmartBulbMeasurementSeries', this.bulbMeasurementSeries);

    // Set up the status changes to happen once per day, and make sure to alternate them between 0 and 1
    this.smartBulbStatusChanges = {};
    this.statusChangesEndDate = {};
    _.each(this.smartBulbs, function (smartBulb, index) {
      var bulbId = smartBulb.id;
      this.numStatusChangesPerBulb = _.random(1, 50);
      this.statusChangesEndDate[bulbId] = this.statusChangesStartDate.plusDays(this.numStatusChangesPerBulb);
      this.smartBulbStatusChanges[bulbId] = _.times(this.numStatusChangesPerBulb, function (statusIndex) {
        return {
          status: (statusIndex % 2),
          start: this.statusChangesStartDate.plusDays(statusIndex),
          end: this.statusChangesStartDate.plusDays(statusIndex + 1),
          parent: { id: this.bulbMeasurementSeriesIds[index] },
        };
      }, this);
      TestApi.upsertBatchEntity(this.ctx, 'SmartBulbMeasurement', this.smartBulbStatusChanges[bulbId]);
    }, this);

    // Wait for setup to complete
    TestApi.waitForSetup(this.ctx, null, 1, 120);
  });

  // Make sure to tear down any objects we've created
  afterAll(function () {
    TestApi.teardown(this.ctx);
  });

  it('should yield a constant status between events when the status changes less frequently than the specified interval', function () {
    var tempArray;
    var metricResults;
    var expectedResults;

    // Test against every measurement for every bulb
    _.each(this.smartBulbs, function (smartBulb) {
      /*
       * Stretch the expected statuses into hourly measurements, with 0s in between actual status change timestamps
       * e.g. [0,1] => [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
       */
      expectedResults = _.flatten(_.map(this.smartBulbStatusChanges[smartBulb.id], function (statusChange, index) {
        tempArray = _.times(24, function () { return 0; });
        if (index > 0) {
          tempArray[0] = 1;
        }
        return tempArray;
      }));

      // Evaluate the metric over the interval we've defined and compare the results to the expected data
      metricResults = SmartBulb.evalMetric({
        id: smartBulb.id,
        expression: 'SwitchCount',
        start: this.statusChangesStartDate,
        end: this.statusChangesEndDate[smartBulb.id],
        interval: 'HOUR',
      }).data();

      expect(metricResults).toEqual(expectedResults);
    }, this);
  });
});
