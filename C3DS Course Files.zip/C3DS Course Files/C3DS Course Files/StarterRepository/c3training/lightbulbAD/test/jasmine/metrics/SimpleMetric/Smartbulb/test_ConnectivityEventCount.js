/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

var filename = 'test_ConnectivityEventCount';

describe(filename, function () {
  // Set up any necessary data before running any tests
  beforeAll(function () {
    this.setup = TestApi.setupEventMetricTest(TestEventMetricSetupSpec.make({
      filename: filename,
      eventType: 'Connectivity',
      eventCode: 'C',
    }));
  });

  // Make sure to tear down any objects we've created
  afterAll(function () {
    TestApi.teardown(this.setup.context);
  });

  it('should return the correct number of events when evaluated over the full event date span', function () {
    var metricResults;
    var expectedEvents;
    var numEvents;

    // Evaluate the metric over the interval we've defined and compare the results to the expected data
    _.each(this.setup.smartBulbs, function (smartBulb) {
      expectedEvents = this.setup.smartBulbEvents[smartBulb.id];
      metricResults = SmartBulb.evalMetric({
        id: smartBulb.id,
        expression: 'ConnectivityEventCount',
        start: this.setup.start,
        end: this.setup.end,
        interval: 'HOUR',
      }).data();

      numEvents = _.reduce(metricResults, function (prev, value) {
        return prev + value;
      }, 0);
      expect(numEvents).toEqual(expectedEvents.length);
    }, this);
  });
});
