/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

var filename = 'test_DurationOnInHours';

describe(filename, function () {
  // Set up any necessary data before running any tests
  beforeAll(function () {
    this.generateSmartBulbMeasurementSeries = function (bulb) {
      return {
        id: 'SMS-' + bulb.id,
        smartBulb: bulb,
        interval: 'HOUR',
        treatment: 'rate',
      };
    };

    // Set up fundamental, shared variables
    this.context = TestApi.createContext(filename, null, [AnalyticsQueue]);
    this.numTestSmartBulbs = 3;
    this.numStatusChangesPerBulb = {};
    this.statusChangesStartDate = DateTime.now().plusYears(-1).toDateMidnight();

    // Set up the smart bulbs to be measured
    this.smartBulbs = _.times(this.numTestSmartBulbs, function (idNum) {
      return { id: 'SmartBulb-' + idNum };
    });

    // Set up the status changes to happen once per day, and make sure to alternate them between 0 and 1
    this.smartBulbStatusChanges = {};
    this.statusChangesEndDates = {};
    _.each(this.smartBulbs, function (smartBulb) {
      var days = 20 + _.random(30);
      this.numStatusChangesPerBulb[smartBulb.id] = days;
      var statusIndices = _.range(this.numStatusChangesPerBulb[smartBulb.id]);
      this.smartBulbStatusChanges[smartBulb.id] = _.map(statusIndices, function (statusIndex) {
        return {
          value: (statusIndex % 2),
          timestamp: this.statusChangesStartDate.plusDays(statusIndex),
          parent: { id: smartBulb.id },
        };
      }, this);
      this.statusChangesEndDates[smartBulb.id] = this.statusChangesStartDate.plusDays(days);
      TestApi.upsertBatchEntity(this.context, 'PowerGridStatusSet', this.smartBulbStatusChanges[smartBulb.id]);
    }, this);

    // Set up the bulbs' measurement series
    this.smartBulbMeasurementSeries = _.map(this.smartBulbs, this.generateSmartBulbMeasurementSeries);

    // Create the entities to test
    TestApi.upsertBatchEntity(this.context, 'SmartBulb', this.smartBulbs);
    TestApi.upsertBatchEntity(this.context, 'SmartBulbMeasurementSeries', this.smartBulbMeasurementSeries);

    // Set up the lumen measurement values
    this.smartBulbMeasurements = {};
    var numHoursToTestPerBulb = 0;
    _.each(this.smartBulbMeasurementSeries, function (measurementSeries) {
      // Create a measurement on each hour for every bulb
      numHoursToTestPerBulb = this.numStatusChangesPerBulb[measurementSeries.smartBulb.id] * 24;
      this.smartBulbMeasurements[measurementSeries.id] = _.times(numHoursToTestPerBulb, function (measurementIndex) {
        /*
         * Set the status of the lightbulb to on every other day, following the pattern
         * of the power grid status.
         */
        var status = measurementIndex % 48 >= 24 ? 1 : 0;
        return {
          lumens: 100,
          status: status,
          parent: measurementSeries,
          start: this.statusChangesStartDate.plusHours(measurementIndex),
          end: this.statusChangesStartDate.plusHours(measurementIndex + 1),
        };
      }, this);
      TestApi.upsertBatchEntity(this.context, 'SmartBulbMeasurement', this.smartBulbMeasurements[measurementSeries.id]);
    }, this);

    // Wait for setup to complete
    TestApi.waitForSetup(this.context, null, 1, 120);
  });

  // Make sure to tear down any objects we've created
  afterAll(function () {
    TestApi.teardown(this.context);
  });

  it('should yield a constant status between events when the status changes less frequently than the specified interval', function () {
    var runningExpectedDuration;
    var tempArray;
    var metricResults;
    var expectedResults;
    var statusChangesEndDate;

    // Test against every measurement for every bulb
    _.each(this.smartBulbs, function (smartBulb) {
      runningExpectedDuration = 0;

      /*
       * Expect the results to be an hourly list of cumulative durations
       * e.g. [0,1] => [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
       */
      expectedResults = _.flatten(_.map(this.smartBulbStatusChanges[smartBulb.id], function (statusChange) {
        if (statusChange.value == 1) {
          tempArray = _.range(runningExpectedDuration + 1, runningExpectedDuration + 25);
          runningExpectedDuration += 24;
        } else {
          tempArray = _.times(24, function () { return runningExpectedDuration; });
        }
        return tempArray;
      }));

      // Evaluate the metric over the interval we've defined and compare the results to the expected data
      statusChangesEndDate = this.statusChangesEndDates[smartBulb.id];
      metricResults = SmartBulb.evalMetric({
        id: smartBulb.id,
        expression: 'DurationOnInHours',
        start: this.statusChangesStartDate,
        end: statusChangesEndDate,
        interval: 'HOUR',
      }).data();

      expect(metricResults).toEqual(expectedResults);
    }, this);
  });
});
