/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

var filename = 'test_AdminGroups';
describe(filename, function () {
  /*
   * Set-up the TestApi Context (This allows types to be created and removed to leave the environment
   * unchanged before and after the test is executed.
   */
  beforeAll(function () {
    this.ctx = TestApi.createContext(filename);

    if (Building.fetchCount({ filter: "id == 'bld1'" }) != 1) {
      TestApi.upsertEntity(this.ctx, 'Building', { id: 'bld1' });
    }
    if (Building.fetchCount({ filter: "id == 'bld2'" }) != 1) {
      TestApi.upsertEntity(this.ctx, 'Building', { id: 'bld2' });
    }

    var apartment1 = TestApi.upsertEntity(this.ctx, 'Apartment', {
      building: { id: 'bld1' },
    });
    var apartment2 = TestApi.upsertEntity(this.ctx, 'Apartment', {
      building: { id: 'bld2' },
    });

    var fxtr1 = TestApi.upsertEntity(this.ctx, 'Fixture', { apartment: apartment1 });
    var fxtr2 = TestApi.upsertEntity(this.ctx, 'Fixture', { apartment: apartment2 });
    var smartBulb1 = TestApi.upsertEntity(this.ctx, 'SmartBulb');
    var smartBulb2 = TestApi.upsertEntity(this.ctx, 'SmartBulb');

    TestApi.upsertBatchEntity(this.ctx, 'SmartBulbToFixtureRelation', [
      { from: smartBulb1, to: fxtr1 },
      { from: smartBulb2, to: fxtr2 },
    ]);

    var measurementSeries = TestApi.upsertEntity(this.ctx, 'SmartBulbMeasurementSeries', { smartBulb: smartBulb1 });
    TestApi.upsertEntity(this.ctx, 'SmartBulbMeasurement', {
      parent: measurementSeries,
      start: DateTime.now().plusHours(-1),
      end: DateTime.now(),
    });

    TestApi.waitForSetup(this.ctx, null, 1, 180);
  });

  describe('members of Building1AnalystGroup', function () {
    it('should only have access to Building.id == bld1', function () {
      TestRunner.asGroup('Building1AnalystGroup', Lambda.fromJavaScript(function (ctx) {
        var buildings = Building.fetch();
        var smartBulbs = SmartBulb.evaluate({
          group: 'currentFixture.apartment.building.id',
          projection: 'currentFixture.apartment.building.id',
        });
        expect(buildings.count).toBe(1);
        expect(smartBulbs.tuples.size()).toBe(1);

        var denied = {
          'SmartBulbMeasurement': ['fetch'],
        };
        TestApi.expectDenied(ctx, denied);
      }).partiallyCall([this.ctx]));
    });
  });

  describe('members of GeneralAnalystGroup', function () {
    it('should have access to all objects', function () {
      TestRunner.asGroup('GeneralAnalystGroup', Lambda.fromJavaScript(function (ctx) {
        var buildings = Building.fetch();
        var smartBulbs = SmartBulb.evaluate({
          group: 'currentFixture.apartment.building.id',
          projection: 'currentFixture.apartment.building.id',
        });
        expect(buildings.count).not.toBe(1);
        expect(smartBulbs.tuples.size()).not.toBe(1);

        var allowed = { 'Building': ['fetch'] };
        TestApi.expectAllowed(ctx, allowed);
      }).partiallyCall([this.ctx]));
    });
  });

  describe('members of BuildingFetchOnlyGroup', function () {
    it('should only have fetch access on building', function () {
      TestRunner.asGroup('BuildingFetchOnlyGroup', Lambda.fromJavaScript(function (ctx) {
        var allowed = { 'Building': ['fetch'] };
        var denied = {
          'Building': ['evaluate'],
          'SmartBulb': ['fetch'],
        };

        TestApi.expectAllowed(ctx, allowed);
        TestApi.expectDenied(ctx, denied);
      }).partiallyCall([this.ctx]));
    });
  });

  afterAll(function () {
    TestApi.teardown(this.ctx);
  });
});
