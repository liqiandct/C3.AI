/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

var filename = 'test_SmartBulb';

describe(filename, function () {
  beforeAll(function () {
    this.context = TestApi.createContext(filename);
    this.conversionFactor = 365 * 24 * 3600 * 1000;

    /*
     * Create a startdate for all the measurements to be taken
     * Important note. We take Today => Strip away time => move to beginning of the month => move 3 days into the past.
     */
    this.end = DateTime.now().clearTime().toDateMidnight();
    this.start = this.end.plusDays(-3);

    this.smartBulbObjects = _.times(2, function (id) {
      return {
        id: 'SmartBulb' + id,
        startDate: this.start,
      };
    }, this);

    TestApi.upsertBatchEntity(this.context, 'SmartBulb', this.smartBulbObjects);

    // Create the SmartBulbMeasurementSeries objects
    this.smartBulbMeasurementSeriesObjects = _.times(2, function (index) {
      return {
        smartBulb: this.smartBulbObjects[index],
        id: 'SBMS_serialNo_' + this.smartBulbObjects[index].id,
        interval: 'DAY',
        treatment: 'rate',
      };
    }, this);
    this.smartBulbMeasurementSeriesObjects = TestApi.upsertBatchEntity(this.context, 'SmartBulbMeasurementSeries', this.smartBulbMeasurementSeriesObjects);

    /*
     * Create the SmartBulbMeasurement objects
     * These are the times in which they should fail.  Lumens 0 and from above
     * status == 1
     */
    this.smartBulbMeasurementObjects = [
      {
        lumens: 0,
        parent: { id: this.smartBulbMeasurementSeriesObjects[0] },
        status: 1,
        start: this.start.plusDays(1),
        end: this.start.plusDays(2),
      },
      {
        lumens: 0,
        parent: { id: this.smartBulbMeasurementSeriesObjects[1] },
        status: 1,
        start: this.start.plusDays(2),
        end: this.start.plusDays(3),
      },
    ];
    TestApi.upsertBatchEntity(this.context, 'SmartBulbMeasurement', this.smartBulbMeasurementObjects);
  });

  afterAll(function () {
    TestApi.teardown(this.context);
  });

  describe('::lifeSpan', function () {
    it('should see that SmartBulb0 failed 2 days into its life', function () {
      this.expectedValue = (this.end.plusDays(-1) - this.start) / this.conversionFactor;

      // Within a 1 second window
      this.result = SmartBulb.lifeSpanInYears('SmartBulb0');
      expect(this.result).toBeGreaterThan(this.expectedValue - 1000);
      expect(this.result).toBeLessThan(this.expectedValue + 1000);
    });

    it('should see that SmartBulb1 failed 2 days into its life ago', function () {
      this.expectedValue = (this.end - this.start) / this.conversionFactor;

      // Within a 1 second window
      this.result = SmartBulb.lifeSpanInYears('SmartBulb1');
      expect(this.result).toBeGreaterThan(this.expectedValue - 1000);
      expect(this.result).toBeLessThan(this.expectedValue + 1000);
    });
  });

  describe('::shortestLifeSpanBulb', function () {
    it('should return SmartBulb0', function () {
      expect(SmartBulb.shortestLifeSpanBulb()).toEqual('SmartBulb0');
    });
  });
});
