/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

var filename = 'test_AverageVoltage';

describe(filename, function () {
  // Set up any necessary data before running any tests
  beforeAll(function () {
    // Set up helper functions for creating consistent IDs for test objects
    this.generateSmartBulbId = function (idNum) {
      return 'SmartBulb' + idNum;
    };

    this.generateSmartBulbMeasurementSeriesId = function (idNum) {
      return 'SMS_' + idNum;
    };

    // Set up fundamental, shared variables
    var self = this;
    this.context = TestApi.createContext(filename, null, [AnalyticsQueue]);
    this.numTestSmartBulbs = 3;
    this.numTestMeasurementsPerBulb = 10;
    this.measurementStartDate = DateTime.now().plusYears(-7).clearTime();
    this.measurementEndDate = this.measurementStartDate.plusHours(this.numTestMeasurementsPerBulb);

    // Set up the smart bulbs to be measured
    this.smartBulbs = _.map(_.range(this.numTestSmartBulbs), function (index) {
      return { id: self.generateSmartBulbId(index) };
    });

    // Set up the measurement serieses
    this.smartBulbMeasurementSerieses = _.map(this.smartBulbs, function (smartBulb) {
      return {
        id: self.generateSmartBulbMeasurementSeriesId(smartBulb.id),
        smartBulb: { id: smartBulb.id },
        interval: 'HOUR',
        treatment: 'rate',
      };
    });

    // Set up the voltage measurement values
    this.smartBulbMeasurements = {};
    _.each(this.smartBulbMeasurementSerieses, function (measurementSeries) {
      var measurementIndices = _.range(self.numTestMeasurementsPerBulb);
      self.smartBulbMeasurements[measurementSeries.id] = _.map(measurementIndices, function (measurementIndex) {
        return {
          voltage: _.random(60, 130),
          parent: measurementSeries.id,
          start: self.measurementStartDate.plusHours(measurementIndex),
          end: self.measurementStartDate.plusHours(measurementIndex + 1),
        };
      });
    });

    // Create the entities to test
    TestApi.upsertBatchEntity(this.context, 'SmartBulb', this.smartBulbs);
    TestApi.upsertBatchEntity(this.context, 'SmartBulbMeasurementSeries', this.smartBulbMeasurementSerieses);
    _.each(_.keys(self.smartBulbMeasurements), function (measurementSeriesKey) {
      TestApi.upsertBatchEntity(self.context, 'SmartBulbMeasurement', self.smartBulbMeasurements[measurementSeriesKey]);
    });

    // Wait for setup to complete
    TestApi.waitForSetup(this.context, null, 1, 120);
  });

  // Make sure to tear down any objects we've created
  afterAll(function () {
    TestApi.teardown(this.context);
  });

  it('should return all measurements when evaluated over the full measurement date span', function () {
    var self = this;
    var measurementSeries;
    var expectedMeasurements;
    var metricResults;

    // Evaluate the metric over the interval we've defined and compare the results to the expected data
    _.each(self.smartBulbs, function (smartBulb, index) {
      measurementSeries = self.smartBulbMeasurementSerieses[index];
      expectedMeasurements = _.pluck(self.smartBulbMeasurements[measurementSeries.id], 'voltage');
      metricResults = SmartBulb.evalMetric({
        id: smartBulb.id,
        expression: 'AverageVoltage',
        start: self.measurementStartDate,
        end: self.measurementEndDate,
        interval: 'HOUR',
      }).data();

      expect(metricResults).toEqual(expectedMeasurements);
    });
  });
});
