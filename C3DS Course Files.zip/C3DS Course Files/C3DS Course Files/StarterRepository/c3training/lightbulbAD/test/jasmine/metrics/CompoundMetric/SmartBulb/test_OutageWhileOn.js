/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

var filename = 'test_OutageWhileOn';

describe(filename, function () {
  // Set up any necessary data before running any tests
  beforeAll(function () {
    this.numberOfHours = 30;
    this.setup = TestApi.setupEventMetricTest(TestEventMetricSetupSpec.make({
      filename: filename,
      eventType: 'Outage',
      eventCode: 'O',
      numberOfEventsPerBulb: this.numberOfHours,
    }));
    this.bulbMeasurementSeries = _.times(this.setup.smartBulbs.length, function (index) {
      return {
        smartBulb: this.setup.smartBulbs[index],
        interval: 'HOUR',
      };
    }, this);
    this.bulbMeasurementSeriesIds = TestApi.upsertBatchEntity(this.setup.context, 'SmartBulbMeasurementSeries', this.bulbMeasurementSeries);
    this.smartBulbStatusChanges = {};

    // Set up smart bulb statuses (SmartBulbStatus) that change once per hour, alternating them between 0 and 1
    _.each(this.setup.smartBulbs, function (smartBulb, index) {
      this.smartBulbStatusChanges[smartBulb.id] = _.times(this.numberOfHours, function (statusIndex) {
        return {
          status: (statusIndex % 2),
          start: this.setup.start.plusHours(statusIndex),
          end: this.setup.start.plusHours(statusIndex + 1),
          parent: { id: this.bulbMeasurementSeriesIds[index] },
        };
      }, this);
      TestApi.upsertBatchEntity(this.setup.context, 'SmartBulbMeasurement', this.smartBulbStatusChanges[smartBulb.id]);
    }, this);

    // Wait for setup to complete
    TestApi.waitForSetup(this.setup.context, null, 1, 120);
  });

  // Make sure to tear down any objects we've created
  afterAll(function () {
    TestApi.teardown(this.setup.context);
  });

  it('should yield a constant status between events when the status changes less frequently than the specified interval', function () {
    var metricResults;
    var expectedValues;

    // Evaluate the metric over the interval we've defined and compare the results to the expected data
    _.each(this.setup.smartBulbs, function (smartBulb) {
      expectedValues = _.times(this.numberOfHours, function (index) {
        return (index % 2);
      });
      metricResults = SmartBulb.evalMetric({
        id: smartBulb.id,
        expression: 'OutageWhileOn',
        start: this.setup.start,
        end: this.setup.end,
        interval: 'HOUR',
      }).data();
      expect(metricResults).toEqual(expectedValues);
    }, this);
  });
});
