/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

var filename = 'test_Status';

describe(filename, function () {
  // Set up any necessary data before running any tests
  beforeAll(function () {
    // Set up helper functions for creating consistent IDs for test objects
    this.generateSmartBulb = function (idNum) {
      return { id: 'SmartBulb-' + idNum };
    };

    this.generateSmartBulbMeasurementSeries = function (bulb) {
      return {
        id: 'SMS-' + bulb.id,
        smartBulb: bulb,
        interval: 'HOUR',
        treatment: 'rate',
      };
    };

    // Set up fundamental, shared variables
    this.context = TestApi.createContext(filename, null, [AnalyticsQueue]);
    this.numTestSmartBulbs = 3;
    this.numDays = 50;
    this.measurementsStartDate = DateTime.now().plusYears(-1).toDateMidnight();
    this.measurementsEndDate = this.measurementsStartDate.plusDays(this.numDays);

    // Set up the smart bulbs to be measured
    this.smartBulbs = _.times(this.numTestSmartBulbs, this.generateSmartBulb);

    // Set up smart bulb statuses (SmartBulbStatus) that change once per day, alternating them between 0 and 1
    this.smartBulbStatusChanges = {};
    _.each(this.smartBulbs, function (smartBulb) {
      this.smartBulbStatusChanges[smartBulb.id] = _.times(this.numDays, function (statusIndex) {
        return {
          value: (statusIndex % 2),
          timestamp: this.measurementsStartDate.plusDays(statusIndex),
          parent: smartBulb,
        };
      }, this);
      TestApi.upsertBatchEntity(this.context, 'PowerGridStatusSet', this.smartBulbStatusChanges[smartBulb.id]);
    }, this);

    // Set up the bulbs' measurement series
    this.smartBulbMeasurementSeries = _.map(this.smartBulbs, this.generateSmartBulbMeasurementSeries);

    // Create the entities to test
    TestApi.upsertBatchEntity(this.context, 'SmartBulb', this.smartBulbs);
    TestApi.upsertBatchEntity(this.context, 'SmartBulbMeasurementSeries', this.smartBulbMeasurementSeries);

    // Set up the status measurement values
    this.smartBulbMeasurements = {};
    var numHoursToTestPerBulb = 0;
    _.each(this.smartBulbMeasurementSeries, function (measurementSeries) {
      // Create a measurement on each hour for every bulb
      numHoursToTestPerBulb = this.numDays * 24;
      this.smartBulbMeasurements[measurementSeries.id] = _.times(numHoursToTestPerBulb, function (measurementIndex) {
        // Set status to be 0 and 1 on alternate days
        var status = measurementIndex % 48 >= 24 ? 1 : 0;
        return {
          status: status,
          parent: measurementSeries,
          start: this.measurementsStartDate.plusHours(measurementIndex),
          end: this.measurementsStartDate.plusHours(measurementIndex + 1),
        };
      }, this);
      TestApi.upsertBatchEntity(this.context, 'SmartBulbMeasurement', this.smartBulbMeasurements[measurementSeries.id]);
    }, this);

    // Wait for setup to complete
    TestApi.waitForSetup(this.context, null, 1, 120);
  });

  // Make sure to tear down any objects we've created
  afterAll(function () {
    TestApi.teardown(this.context);
  });

  it('should yield a constant status between events when the status changes', function () {
    var metricResults;
    var expectedResults;

    // Test against every measurement for every bulb
    _.each(this.smartBulbs, function (smartBulb) {
      /*
       * Stretch the expected statuses into hourly measurements
       * e.g. [0,1] => [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
       */
      expectedResults = _.flatten(_.map(this.smartBulbStatusChanges[smartBulb.id], function (statusChange) {
        return _.times(24, function () {
          return statusChange.value;
        });
      }, this));

      metricResults = SmartBulb.evalMetric({
        id: smartBulb.id,
        expression: 'Status',
        start: this.measurementsStartDate,
        end: this.measurementsEndDate,
        interval: 'HOUR',
      }).data();

      expect(metricResults).toEqual(expectedResults);
    }, this);
  });
});
