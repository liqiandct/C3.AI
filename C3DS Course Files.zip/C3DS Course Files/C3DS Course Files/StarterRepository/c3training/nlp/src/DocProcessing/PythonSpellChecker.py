from itertools import islice

import collections
from textblob._text import Spelling
from textblob.en import spelling as en_spelling


LANG_TO_SPELLING = {
    'en': en_spelling
}


class PythonSpellChecker(object):
    """
    Powered by textblob. It is expensive to create as it parses entire lexicon.

    TODO the TextBlob spellchecker is very naive and not performant, we should consider switching the
    implementation to [Hunspell](http://hunspell.github.io/) which is used
    by [spaCy](https://github.com/tokestermw/spacy_hunspell)
    """

    def __init__(self, c3_python_spell_checker):
        """
        Args:
            c3_python_spell_checker (dictionary with info PythonSpellChecker.c3typ)
        """

        if not isinstance(c3_python_spell_checker, dict):
            c3_python_spell_checker = c3_python_spell_checker.toJson()
        if 'locale' not in c3_python_spell_checker and 'wordCounts' not in c3_python_spell_checker:
            raise ValueError('You must provide either a known "locale" or "wordCounts" to PythonSpellChecker')
        lang = c3_python_spell_checker.get('locale', {}).get('language')
        if lang is not None:
            if lang not in LANG_TO_SPELLING:
                raise ValueError('Language "{}" is not supported, valid locale '
                                 'languages for PythonSpellChecker are "{}". If your language is not supported, '
                                 'change PythonCorrectSpellingSpec.locale to None'
                                 .format(lang, LANG_TO_SPELLING.keys()))
            self.spelling = LANG_TO_SPELLING[lang]
        else:
            self.spelling = Spelling(path='/dev/null')

        self.spelling.load()

        words_map = c3_python_spell_checker.get('wordCounts', {})
        for k, v in words_map.items():
            # Must use dict.__setitem__, see
            # https://github.com/sloria/TextBlob/blob/767d4a89ff00876fa76a1877e92830be86fdb7b3/textblob/_text.py#L77
            dict.__setitem__(self.spelling, k, v)

    def validWord(self, word):
        """
        Checks whether the word is valid

        Input:
            word: the word to check

        Output: boolean for whether the word is valid
        """
        return word in self.spelling

    def correctWord(self, word):
        """
        If the input word is in the language or added wordList, simply returns it.
        If not, returns the closest valid word to the input 'word' or, if no valid word is 'close' to the input word,
        the word itself.

        Input:
            word: string of word to get corrected

        Output: string most probable match
        """
        return word if self.validWord(word) else self.wordSuggestions(word, 1)[0]

    def wordSuggestions(self, word, numberOfSuggestions):
        """
        Input:
            word: string of word to generate suggestions for
            numberOfSuggestions: The maximum number of suggestions you would like

        Output: A list of valid words close to the given input if the input word is not valid
        """
        return [a[0] for a in islice(self.spelling.suggest(word), numberOfSuggestions)]


# This is useful for directly calling correctWords many times in PythonTextProcessor.py within
# the same process without leaving Python layer.
# TODO: support (or error) if user tries to use multiple PythonSpellChecker steps in a PreProcessSpec
# TODO: if we are using PersistantActionEngine then this should only be built once ... but need to handle when
# user is doing things like multiple language.
_spellchecker = None


def _get_spellchecker(this):
    global _spellchecker
    if _spellchecker is None:
        _spellchecker = PythonSpellChecker(this)
    return _spellchecker


def correctWord(this, word):
    return _get_spellchecker(this).correctWord(word)


def correctWords(this, words, removeMisspellings):
    spell_checker = _get_spellchecker(this)
    misspellingsCounts = collections.defaultdict(int)
    corrected = []
    for word in words:
        if spell_checker.validWord(word):
            corrected.append(word)
        else:
            misspellingsCounts[word] += 1
            if not removeMisspellings:
                corrected.append(spell_checker.wordSuggestions(word, 1)[0])
    return c3.PythonSpellCheckerResult(words=corrected,
                                       misspellingsCounts=misspellingsCounts)


def validWord(this, word):
    return _get_spellchecker(this).validWord(word)


def wordSuggestions(this, word, numberOfSuggestions):
    return _get_spellchecker(this).wordSuggestions(word, numberOfSuggestions)
