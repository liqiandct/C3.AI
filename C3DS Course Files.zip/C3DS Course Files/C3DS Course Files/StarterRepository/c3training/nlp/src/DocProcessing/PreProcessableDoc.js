/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

function preProcessDocs(preProcessSpec, filter) {
  if (!(preProcessSpec.steps && preProcessSpec.steps.length > 0)) {
    if (!preProcessSpec.id) {
      throw Error("preProcessSpec for DocPreProcessingJob must have at least one step");
    } else {
      preProcessSpec = PythonTextPreProcessSpec.fetch({
        filter: Filter.eq("id", preProcessSpec.id),
        include: "id, steps",
        limit: 1
      }).objs.at(0);
      if (!(preProcessSpec.steps && preProcessSpec.steps.length > 0)) {
        throw Error("preProcessSpec for DocPreProcessingJob must have at least one step");
      }
    }
  }
  if (!preProcessSpec.id) {
    preProcessSpec.id = preProcessSpec.upsert().id;
  }

  var job = DocPreProcessingJob.make({
    include: "id, text",
    targetType: this,
    preProcessSpec: preProcessSpec
  });
  if (filter) {
    job.filter = filter;
  }
  job = job.upsert();
  job.start();
  return job;
}
