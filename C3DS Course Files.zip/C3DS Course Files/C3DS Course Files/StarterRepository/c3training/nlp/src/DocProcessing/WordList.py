# Creates a WordList with the given name whose allowed words are those in the `words` string.
# (to be split on whitespace).
def fromWordString(name, words):
    return fromWordList(name, words.split())


# Creates a WordList with the given name whose allowed words are those in the `words` array.
def fromWordList(name, words):
    return c3.WordList(name=name, words=" ".join(set(words)))
