/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

function map(batch, objs, job) {
  var preProcessSpec = job.preProcessSpec;
  if (!(preProcessSpec.steps && preProcessSpec.steps.length > 0)) {
    if (!preProcessSpec.id) {
      throw Error("preProcessSpec for DocPreProcessingJob must have at least one step");
    } else {
      preProcessSpec = PythonTextPreProcessSpec.fetch({
        filter: Filter.eq("id", preProcessSpec.id),
        include: "id, steps",
        limit: 1
      }).objs.at(0);
      if (!(preProcessSpec.steps && preProcessSpec.steps.length > 0)) {
        throw Error("preProcessSpec for DocPreProcessingJob must have at least one step");
      }
    }
  }
  var objType = objs[0].type();
  //Check whether...
  // 1. the objs mixin PreProcessable doc. As long as users go through PreProcessableDoc, this should not be an issue.
  if (!_.some(objType.mixins(), function(c3Typ) { return c3Typ.typeName() == "PreProcessableDoc"; })) {
    throw Error("DocPreProcessingJob can only be run on types that mix PreProcessableDoc");
  }
  // 2. the objs have their text field populated already. If not, we need to fetch again.
  if (!_.some(objs, function(obj) { return (obj.text && obj.text.length > 0); })) {
    var objIds = _.pluck(objs, "id");
    objs = objType.fetch({
      include: "id, text",
      filter: Filter.intersects("id", objIds),
      limit: objIds.length
    }).objs;
  }
  var objsWithText = _.filter(objs, function(obj) { return (obj.text && obj.text.length > 0); });
  if (objsWithText.length == 0) {
    return;
  }
  var rawDocuments = _.pluck(objsWithText, 'text');
  var processedDocuments = PythonTextProcessor.preProcessDocumentsBatch(rawDocuments, preProcessSpec);
  var now = new Date();
  _.each(objsWithText, function(obj, i) {
    obj.preProcessedText = PreProcessedText.make({
      preProcessSpec: preProcessSpec,
      processingDate: now,
      processedText: processedDocuments[i]
    });
  });
  objType.mergeBatch(objsWithText, {include: "preProcessedText"});
}
