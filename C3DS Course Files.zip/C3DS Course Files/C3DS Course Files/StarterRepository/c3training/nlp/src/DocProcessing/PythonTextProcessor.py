from nltk.corpus import stopwords
import nltk
import string
import sys
from collections import Counter, OrderedDict
from nltk.stem.wordnet import WordNetLemmatizer
from nltk import pos_tag
from nltk.stem.snowball import SnowballStemmer
import re
import itertools

# These words have special meaning in Javascript and/or the C3 JS type system, so they cannot be returned as keys in a
# map.
c3_protected_words = {
    'set': 'seet',
    'get': 'geet',
    'type': 'typpe'
}

# languages supported in anyof(stem, stopwords)
supported_languages = {
    'da': 'danish',
    'de': 'german',
    'en': 'english',
    'es': 'spanish',
    'fi': 'finnish',
    'fr': 'french',
    'hu': 'hungarian',
    'it': 'italian',
    'nb': 'norwegian',
    'nl': 'dutch',
    'pt': 'portuguese',
    'ro': 'romanian',
    'ru': 'russian',
    'sv': 'swedish',
    'tr': 'turkish'
}


def text_processor_from_string(toProcess, delimiter):
    """Creates a PythonTextProcessor from an input string by splitting on 'delimiter' (default is whitespace)."""

    toProcess = toProcess.encode('ascii', 'replace')  # replace non ascii characters

    for str_from, str_to in c3_protected_words.items():
        toProcess = toProcess.replace(str_from, str_to)

    # finally split
    words = re.split(delimiter, toProcess)

    return c3.PythonTextProcessor(words=filter(None, words))


def get_words(this):
    """Get the PythonTextProcessor.words and remove empty strings/None value from that list."""
    return filter(None, this.toJson().get('words', []))


# nltk download will write to std out so we need to silence it
class GhostWriter(object):
    def write(self, s):
        pass


def _download_from_nltk(package):
    ghost_writer = GhostWriter()
    std_out = sys.stdout
    sys.stdout = ghost_writer
    nltk.download(package)
    sys.stdout = std_out


def removePunctuation(this):
    """ Removes all characters in string.punctuation characters from words in the
    PythonTextProcessor."""
    return removeCharacters(this, string.punctuation)


def removeCharacters(this, blackList):
    black_list = str(blackList)
    new_words = [str(w).translate(None, black_list) for w in get_words(this)]
    return c3.PythonTextProcessor(words=new_words)


def toLowerCase(this):
    return c3.PythonTextProcessor(words=[w.lower() for w in get_words(this)])


def removeWords(this, blackList):
    blacklist_set = set(blackList)
    return c3.PythonTextProcessor(words=filter(lambda w: w not in blacklist_set, get_words(this)))


def removeStopWordsForLocale(this, locale):
    lang = locale['language']
    lang = supported_languages.get(lang, lang)
    try:
        stop_words = stopwords.words(lang)
    except IOError:
        raise ValueError('Language %s is unsupported' % lang)
    except LookupError:
        _download_from_nltk('stopwords')
        stop_words = stopwords.words(lang)

    return removeWords(this, stop_words)


def dropWordLengths(this, minLength, maxLength):
    words = get_words(this)
    if not minLength:
        minLength = 1
    words = filter(lambda w: minLength <= len(w), words)
    if maxLength:
        words = filter(lambda w: len(w) <= maxLength, words)
    return c3.PythonTextProcessor(words=words)


def replaceWords(this, glossary):
    return c3.PythonTextProcessor(words=[glossary.get(w, w) for w in get_words(this)])


def lemmatize(this):
    """ lemmatize uses the nltk lemmatizer in wordnet to get base words
    e.g. 'are' -> 'be', 'wolves' -> 'wolf'
    the above cannot be done by a pure stemmer. However stemming works better in other instances
    e.g. lemmatizing maps 'quickly' -> 'quickly'

    lemmatizer requires a part of speech which is taken from the nltk
    """
    lemmatizer = WordNetLemmatizer()
    try:
        # make sure wordnet and averaged_perceptron_tagger are downloaded
        _ = lemmatizer.lemmatize('cats')
        _ = pos_tag('dogs')
    except LookupError:
        _download_from_nltk('wordnet')
        _download_from_nltk('averaged_perceptron_tagger')

    pos_map = {'N': 'n', 'V': 'v', 'J': 'a', 'P': 'n', 'R': 'r'}  # pos tags are not same
    return c3.PythonTextProcessor(words=[lemmatizer.lemmatize(w, pos_map.get(pos[0], 'n')) for w, pos in pos_tag(get_words(this))])


def stemForLocale(this, locale):
    lang = supported_languages.get(locale['language'], locale['language'])
    try:
        stemmer = SnowballStemmer(lang)
    except IOError:
        raise ValueError('Languge %s is unsupported' % lang)
    except LookupError:
        _download_from_nltk('wordnet')
        stemmer = SnowballStemmer(lang)

    return c3.PythonTextProcessor(words=[stemmer.stem(w) for w in get_words(this)])


# The below functions are necessary so that the type system can fit the steps into the
# anyof in PythonTextPreProcessSpec.steps.
# TODO: Ticket to fix this in pyc3 DATA-1135
def c3_escape_spec(spec):
    return OrderedDict(sorted(spec.items(), key=lambda t: t[0] != 'type'))


def c3_escape_specs(spec):
    spec['steps'] = [c3_escape_spec(step) for step in spec['steps']]
    return spec


def fromString(toProcess, delimiter):
    return text_processor_from_string(toProcess, delimiter)


def toString(this, joiner):
    """Returns a string created by joining the words in the PythonTextProcessor."""
    if joiner is None:
        joiner = ' '
    return joiner.join([w for w in get_words(this)])


def correctSpelling(this, pythonSpellChecker):
    # Because we mixin PythonSpellChecker, we have direct access to correctWords function
    # and do not have to leave the Python layer.
    return c3.PythonTextProcessor(words=correctWords(pythonSpellChecker, get_words(this), False)['words'])


def removeByRegex(this, regex):
    return replaceByRegex(this, regex, '')


def replaceByRegex(this, regex='', replacement=''):
    match = re.compile(regex)
    return c3.PythonTextProcessor(words=[match.sub(replacement, w) for w in get_words(this)])


def preProcess(this, spec):
    for step in spec.get('steps', []):
        type_name = step['type']
        if type_name == 'PythonRemoveWordsSpec':
            this = removeWords(this, step['blackList'])
        elif type_name == 'PythonDropWordLengthsSpec':
            this = dropWordLengths(this, step.get('minLength', None), step.get('maxLength', None))
        elif type_name == 'PythonRemoveCharactersSpec':
            this = removeCharacters(this, step['blackList'])
        elif type_name == 'PythonRemovePunctuationSpec':
            this = removePunctuation(this)
        elif type_name == 'PythonReplaceWordsSpec':
            this = replaceWords(this, step['glossary'])
        elif type_name == 'PythonCorrectSpellingSpec':
            this = correctSpelling(this, step.get('pythonSpellChecker'))
        elif type_name == 'PythonRemoveStopWordsForLocaleSpec':
            this = removeStopWordsForLocale(this, step['locale'])
        elif type_name == 'PythonStemForLocaleSpec':
            this = stemForLocale(this, step['locale'])
        elif type_name == 'PythonToLowerSpec':
            this = toLowerCase(this)
        elif type_name == 'PythonLemmatizeSpec':
            this = lemmatize(this)
        elif type_name == 'PythonReplaceByRegexSpec':
            this = replaceByRegex(this, step.get('regex', None), step.get('replacement', None))
        elif type_name == 'PythonRemoveByRegexSpec':
            this = removeByRegex(this, step.get('regex', None))
        elif type_name == 'PythonSplitByDelimiterSpec':
            this = splitByDelimiter(this, step.get('delimiter', '\\s+'))
        elif type_name == 'PythonReplaceSubstringsSpec':
            this = replaceSubstrings(this, step['glossary'])
        else:
            raise ValueError('%s is not a recognized PythonTextPreProcessSpecStep type' % type_name)

    return this

def splitByDelimiter(this, delimiter):
    list_of_lists = [re.split(delimiter, w) for w in get_words(this)]
    words = list(itertools.chain(*list_of_lists))

    return c3.PythonTextProcessor(words=filter(None, words))

def multiple_replace(text, adict):
    rx = re.compile('|'.join(map(re.escape, adict)))
    def one_xlat(match):
        return adict[match.group(0)]
    return rx.sub(one_xlat, text)

def replaceSubstrings(this, glossary):
    return c3.PythonTextProcessor(words=[multiple_replace(w, glossary) for w in get_words(this)])


def preProcessString(toProcess, delimiter, spec):
    # TODO wrap this differently text_processor_from_string(preProcess(toProcess, spec), delimiter)?
    return preProcess(text_processor_from_string(toProcess, delimiter), spec)


def wordCounts(this):
    return Counter(get_words(this))


def nGrams(this, n):
    if n < 1:
        raise ValueError('n-grams must have length >= 1')
    words = get_words(this)
    return [' '.join(words[i:i + n]) for i in xrange(len(words) - n + 1)]


def nGramCounts(this, n):
    return Counter(nGrams(this, n))


def pGramsCounts(this, minSize, maxSize):
    result = Counter()
    for n in xrange(minSize, maxSize + 1):
        result += nGramCounts(this, n)
    return result


def feature_value_map(text_processor, summarySpec):
    summaryType = summarySpec['type']
    if summaryType == 'WordCountSpec':
        return wordCounts(text_processor)
    elif summaryType == 'NGramCountsSpec':
        return pGramsCounts(text_processor, summarySpec['minNGramLength'], summarySpec['maxNGramLength'])
    else:
        raise ValueError('%s is not a recognized text processor summary function' % summaryType)


def processToFeatures(this, preProcessSpec, summarySpec):
    text_processor = preProcess(this, preProcessSpec)
    return feature_value_map(text_processor, summarySpec)


def processStringToFeatures(toProcess, delimiter, preProcessSpec, summarySpec):
    text_processor = preProcessString(toProcess, delimiter, preProcessSpec)
    return feature_value_map(text_processor, summarySpec)


def processStringToString(toProcess, delimiter, preProcessSpec):
    text_processor = preProcessString(toProcess, delimiter, preProcessSpec)
    return toString(text_processor, ' ')


def processDocumentsBatch(documents, summarySpec, preProcessSpec, keepRawCounts):
    if keepRawCounts is False:
        def doc_result(cur_doc_result):
            return Counter(set(cur_doc_result))
    else:
        def doc_result(cur_doc_result):
            return cur_doc_result
    result = Counter()
    for doc in documents:
        if doc is not None and len(doc) > 0:
            result += doc_result(processStringToFeatures(doc, '\\s+', preProcessSpec, summarySpec))
    return result


def preProcessDocumentsBatch(documents, preProcessSpec):
    return [processStringToString(doc, '\\s+', preProcessSpec) for doc in documents]
