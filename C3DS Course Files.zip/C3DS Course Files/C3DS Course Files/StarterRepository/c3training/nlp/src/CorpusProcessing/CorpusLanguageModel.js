/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

function processAsDataset(model, documents) {
  var features = model.features();

  // process then turn map into array
  var data2d = _.map(documents, function (doc) {
    var docMap = model.preProcess(doc);
    return _.map(features, function(f) {
        return docMap[f] ? docMap[f]: 0.0;
    });
  });
  // flatten data into 1d array
  var dataFlat = _.reduce(data2d, function(flatArray, vector) {
    return flatArray.concat(vector);
  }, []);
  return Dataset.make({
    data: dataFlat,
    indices: {
        0: _.range(documents.length),
        1: features
    }
  });
}

function processCorpus() {
  var documentsPerBatch = 10000;
  var jobs = [];
  var corpusProcessSpec = this.corpusProcessSpec;
  corpusProcessSpec.preProcessSpec.id = PythonTextPreProcessSpec.upsert(corpusProcessSpec.preProcessSpec);
  this.corpusSources.forEach(function(corpusSource) {
    //Rough estimate of 5 documents per type system path
    var documentsPerSourceObject = corpusSource.estimatedDocsPerSourceObj || corpusSource.pathsToDocuments.length * 5;
    var batchSize = Math.floor(documentsPerBatch / documentsPerSourceObject) || 1;
    //can't use include spec here because the `TargetType` parametric type for CorpusSourceProcessingJob is Persistable.
    //Actual doc details will have to be fetched from the `map` function.
    var processingJob = CorpusSourceProcessingJob.make({
      include: "id",
      targetType: corpusSource.srcType,
      filter: corpusSource.srcFilter || "",
      batchSize: batchSize,
      corpusProcessSpec: corpusProcessSpec,
      corpusSource: corpusSource
    });
    processingJob = processingJob.upsert();
    CorpusSourceProcessingJob.start(processingJob);
    jobs.push(processingJob);
  });
  this.processingJobs = jobs;
  return this.upsert();
}

function featureMapFromProcessedResults(rawResult, documentCount) {
  return rawResult;
}

function mergeBatchResults(map1, map2) {
  var map1Value, map2Value;
  for (var key in map2) {
    if (map2.hasOwnProperty(key)) {
      map1Value = map1[key];
      map2Value = map2[key];
      map1[key] = (map1Value != null) ? map1Value + map2Value : map2Value;
    }
  }
  return map1;
}

function features() {
  return _.keys(this.getFeatureMap());
}

function topNFeatures(n, descending) {
  if (n <= 0) {
    throw Error("n must be greater than 0");
  }
  var descendingMultiplier = descending ? -1 : 1;
  var featureMap = this.getFeatureMap();
  return _.chain(featureMap)
          .map(function(val, key) { var obj = {}; obj[key] = val; return obj; })
          .sortBy(function(keyValPair) { return descendingMultiplier * _.values(keyValPair)[0]; })
          .first(n)
          .value();
}

function getFeatureMap() {
  if (this.featureMap) {
    return this.featureMap;
  }

  var model = ensureProcessingJobs(this);
  if (!model.allJobsFinished()) {
    throw Error("Not all processing jobs have completed");
  } else {
    var mergedResults = arryValsToInt(model.processingJobs[0].results(-1));
    if (model.processingJobs.length > 1) {
      model.processingJobs.slice(1).forEach(function(job) { mergedResults = mergeBatchResults(mergedResults, arryValsToInt(job.results(-1))); });
    }
    var documentCount = mergedResults["~~CorpusSourceDocCount~~"];
    delete mergedResults["~~CorpusSourceDocCount~~"];
    model.featureMap = this.type().featureMapFromProcessedResults(mergedResults, documentCount);
    model.documentCount = documentCount;
    model.upsert();
    return model.featureMap;
  }
}

function arryValsToInt(mapResult) {
  var result = {}, val;
  for (var key in mapResult) {
    if (mapResult.hasOwnProperty(key)) {
      val = mapResult[key];
      result[key] = val.first();
    }
  }
  return result;
}

function allJobsFinished() {
  var model = ensureProcessingJobs(this);
  if (! _.find(model.processingJobs, function(job) { return !job.status().isCompleted(); })) {
    return true;
  } else {
    return false;
  }
}

function ensureProcessingJobs(model) {
  if (!model.processingJobs || model.processingJobs.length == 0) {
    model = model.type().fetch({include: "this, processingJobs", filter: Filter.eq("id", model.id)}).objs[0];
    if (!model.processingJobs || model.processingJobs.length == 0) {
      throw Error("No CorpusSourceProcessingJobs found for model.");
    }
    return model;
  } else {
    return model;
  }
}
