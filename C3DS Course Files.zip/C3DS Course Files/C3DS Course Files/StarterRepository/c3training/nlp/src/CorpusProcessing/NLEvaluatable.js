/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

function documentIncludeString(timedDocumentSpecs) {
  var includeStrings = _.map(timedDocumentSpecs, function(documentSpec) {
    var documentPath = documentSpec.pathToDocument;
    var fields =  _.map(documentSpec.textFields, function(field) {return documentPath + "." + field;});
    fields.push(documentPath + "." + documentSpec.datetimeField);
    return fields.join(", ");
  });
  return includeStrings.join(", ");
}

//Extracts all documents and returns as an array of objects with 'text' and 'documentTimestamp' fields.
function extractDocuments(srcObj, timedDocumentSpecs) {
  var documents = [];
  _.forEach(timedDocumentSpecs, function(documentSpec) {
    var timestampField = documentSpec.datetimeField;
    var pathToDocument = documentSpec.pathToDocument;
    var docTimestampsArray = srcObj.at(pathToDocument + "." + timestampField);
    if (!docTimestampsArray && docTimestampsArray.length > 0) {
      //TODO(ihleonard, mark.ulrich, phoebus): CHECK THAT ALL ARE VALID DATETIMES
    }
    _.forEach(documentSpec.textFields, function(field) {
      var docTextArray = srcObj.at(pathToDocument + "." + field);
      //ZIP WITH DATETIMES, push obj if nonempty text
      var timedDocuments = _.map(docTextArray, function(docText, docIndex) {
        return {
          'text': docText,
          'documentTimestamp': docTimestampsArray[docIndex]
        };
      });
      documents = documents.concat(timedDocuments);
    });
  });
  return documents;
}

function sortByDocumentTimestamp(doc1, doc2) {
  return doc1.documentTimestamp - doc2.documentTimestamp;
}

function getTsDataObj(srcObj, spec, timedDocumentSpecs) {
  var type = c3Type(c3CurrentAction().getTarget().getType());
  srcObj = type.fetch({
    limit: 1, include: documentIncludeString(timedDocumentSpecs),
    filter: Filter.eq("id", srcObj.id)
  }).objs[0];
  var documents = extractDocuments(srcObj, timedDocumentSpecs);
  var start = spec.start;
  var end = spec.end;
  var interval = spec.interval;
  var dates = Timeseries.makeNorm(NormTimeseriesObjSpec.make({
    "start": start,
    "end": end,
    "interval": interval})).dates();

  var documentIntervals = _.map(dates, function(timestamp) {
    return {"documentsText": [], "intervalTimestamp": timestamp};
  });
  documents.sort(sortByDocumentTimestamp);
  var dateIndex = 0;
  for (var i = 0; i < documents.length; i++) {
    var doc = documents[i];
    var timestamp = doc.documentTimestamp;
    if (timestamp >= end) break;
    if (timestamp >= start) {
      while (dateIndex + 1 < dates.length && timestamp >= dates[dateIndex + 1]) {
        dateIndex++;
      }
      documentIntervals[dateIndex].documentsText.push(doc.text);
    }
  }

  return {
    "start": start,
    "end": end,
    "interval": interval,
    "documents": documentIntervals
  };
}

function featureCountSeries(obj, spec, metric, processingSpec, timedDocumentSpecs) {
  var tsDataObj = getTsDataObj(obj, spec, timedDocumentSpecs);

  var documentIntervals = tsDataObj.documents;
  delete tsDataObj.documents;
  tsDataObj.data = NLTimeseriesProcessor.processCountIntervals(documentIntervals, processingSpec);

  return Timeseries.makeNorm(NormTimeseriesObjSpec.make(tsDataObj));
}

/**
 * See {@link NLEvaluatable.tfidfSeries}.
 */
function tfidfSeries(obj, spec, metric, corpusModel, timedDocumentSpecs) {
  //CorpusLanguageModel should already have been processed
  if (!corpusModel.featureMap || !(corpusModel.corpusProcessSpec && corpusModel.corpusProcessSpec.preProcessSpec)) {
    corpusModel = corpusModel.type().fetch({
      include: "featureMap, corpusProcessSpec.preProcessSpec.steps, corpusProcessSpec.docSummarySpec",
      filter: Filter.eq("id", corpusModel.id), limit: 1
    }).objs[0];
    if (!corpusModel.featureMap || !(corpusModel.corpusProcessSpec)) {
      throw Error("The CorpusLanguageModel passed to tfidfSeries should already have been processed");
    }
  }
  var tsDataObj = getTsDataObj(obj, spec, timedDocumentSpecs);
  var documentIntervals = tsDataObj.documents;
  delete tsDataObj.documents;
  tsDataObj.data = NLTimeseriesProcessor.processTfidfIntervals(documentIntervals, corpusModel);

  return Timeseries.makeNorm(NormTimeseriesObjSpec.make(tsDataObj));
}
