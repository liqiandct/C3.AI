/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

function processThenExtractFeature(tsMap, feature, corpusModel) {
  var textProcessingSpecs = corpusModel.corpusProcessSpec.processTextSpecs;
  if (!textProcessingSpecs) {
    textProcessingSpecs = corpusModel.get('corpusProcessSpec.processTextSpecs');
  }
  var processedFeature = PythonTextProcessor.processStringToString(feature, "\\s+", False, False, textProcessingSpecs);
  return extractFeature(tsMap, processedFeature, corpusModel);
}

function extractFeature(tsMap, feature) {
  // extract feature's value in each interval
  var data = _.map(tsMap.data(), function(map) {
    var val = map.value[feature];
    return val ? val : 0.0;
  });
  return Timeseries.makeNorm(NormTimeseriesDoubleSpec.make({
    start: Timeseries.start(tsMap),
    end: Timeseries.end(tsMap),
    interval: Timeseries.interval(tsMap),
    data: Double.array(data)
  }));
}

function nMostProminentFeatures(tsMap, n) {
    //transform from MappObj -> map
  var mapps = _.map(tsMap.m_data, function(mappObj) {
    return mappObj.toMapp();
  });
  var topNData = _.map(mapps, function(mapp) {
    var topN = _.sortBy(_.pairs(mapp), function(keyValuePair) { return keyValuePair[1]; }).slice(n);
    return _.map(topN, function(keyValuePair) { return keyValuePair[0]; });
  });
  return Timeseries.makeNorm(NormTimeseriesStringSpec.make({
    start: Timeseries.start(tsMap),
    end: Timeseries.end(tsMap),
    interval: Timeseries.interval(tsMap),
    data: NLFunctionLibrary.nMostProminentFeatures_pyhelp(mapps, n)
  }));
}
