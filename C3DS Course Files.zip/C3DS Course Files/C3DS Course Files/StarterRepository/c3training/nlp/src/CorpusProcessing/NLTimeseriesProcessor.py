def process_interval(docs_interval, processingSpec):
    """returns a mapp for an interval represented as an array of documents in
    this interval"""
    if docs_interval is None or len(docs_interval.get("documentsText", [])) == 0:
        return {}
    pre_process_specs = processingSpec["preProcessSpec"]
    doc_summary_spec = processingSpec["docSummarySpec"]
    docs_text = docs_interval.get("documentsText", [])

    return processDocumentsBatch(docs_text, doc_summary_spec, pre_process_specs, True)


def processTfidfIntervals(documentIntervals, corpusModel):
    processingSpec = corpusModel["corpusProcessSpec"]
    processed_intervals = [process_interval(interval, processingSpec) for interval in documentIntervals]
    idfs = corpusModel["featureMap"]
    if isinstance(idfs, str) or isinstance(idfs, unicode):
         idfs = json.loads(idfs)# featureMap has type `json`, and is passed as a string
    # Should this processing be done in JS/Java to avoid passing the model into python?
    processed_intervals = [{feature: float(count) * idfs.get(feature, 1) for feature, count in interval.items()}
                           for interval in processed_intervals]

    return [c3.FeatureValueMap(value=interval_result) for interval_result in processed_intervals]


def processCountIntervals(documentIntervals, processingSpec):
    return [c3.FeatureValueMap(value=process_interval(interval, processingSpec)) for interval in documentIntervals]

