import heapq

def topN(mapp, n):
    """returns the n keys with the largest values in map mapp represented as a string"""
    value_key_tuples = [(v, k) for k, v in mapp.items()]
    return ", ".join([k for _, k in heapq.nlargest(n, value_key_tuples)])


def nMostProminentFeatures_pyhelp(maps, n):
    return [topN(m, n) for m in maps]
