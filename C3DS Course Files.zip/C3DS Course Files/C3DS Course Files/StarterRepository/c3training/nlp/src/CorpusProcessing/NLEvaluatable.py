def get_feature_value(mapp, feature):
    """gets feature value from MappObj mapp"""
    return mapp.get("value", {}).get(feature, {"value": 0.0})["value"]

def empty(mapp):
    """returns 0 if MappObj mapp is empty, 1 if not"""
    if mapp.get("value") is not None:
        return 0
    else:
        return 1


# private helper
def to_row_orient_flat_data(col_orient_flat_data, shape):
    return np.reshape(col_orient_flat_data, shape, "F").ravel()


def createNLDatasetWEmpty_py(tsMaps, dates, features, expressions, vtype):
    """creates a Dataset keeping rows corresponding to empty (no documents) intervals"""
    if not expressions:
        expressions = []

    data = [get_feature_value(m, f) for f in features for _, idt in tsMaps["result"].items() for m in idt[vtype]["m_data"]]
    other_data = [d for expr in expressions for _, idt in tsMaps["result"].items() for d in idt[expr]["m_data"]]
    rows = [ids + "_" + date for ids, _ in tsMaps["result"].items() for date in dates] # rows are id_timestamp

    all_data = data + other_data
    shape = [len(rows), len(features) + len(expressions)]
    row_data = to_row_orient_flat_data(all_data, shape)

    return c3.Dataset(m_data=row_data,
                      indices={0: rows, 1: features + expressions},
                      shape=shape)


def createNLDatasetWoEmpty_py(tsMaps, dates, features, expressions, vtype):
    """creates a Dataset without rows corresponding to empty (no documents) intervals"""
    if not expressions:
        expressions = []

    empty_interval = set([(ids, i) for ids, idt in tsMaps["result"].items() for i, m in enumerate(idt[vtype]["m_data"]) if empty(m)])
    data = [get_feature_value(m, f) for f in features for ids, idt in tsMaps["result"].items() for i, m in enumerate(idt[vtype].get("m_data", [])) if not (ids, i) in empty_interval]
    other_data = [d for expr in expressions for ids, idt in tsMaps["result"].items() for i, d in enumerate(idt[expr].get("m_data", [])) if not (ids, i) in empty_interval]

    rows = [ids + "_" + date for ids, _ in tsMaps["result"].items() for i, date in enumerate(dates) if not (ids, i) in empty_interval]

    all_data = data + other_data
    shape = [len(rows), len(features) + len(expressions)]
    row_data = to_row_orient_flat_data(all_data, shape)

    return c3.Dataset(m_data=row_data,
                      indices={0: rows, 1: features + expressions},
                      shape=shape)
