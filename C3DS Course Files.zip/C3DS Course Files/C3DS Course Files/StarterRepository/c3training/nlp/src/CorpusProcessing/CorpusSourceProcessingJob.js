/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

function map(batch, objs, job) {
  var documentsBatch = [];
  var preProcessingSpecs = job.corpusProcessSpec.preProcessSpec || {};
  var docSummarySpec = job.corpusProcessSpec.docSummarySpec;
  var ids = _.pluck(objs, 'id');
  objs = job.corpusSource.srcType.toType().fetch({
    include: job.corpusSource.pathsToDocuments.join(", "),
    filter: Filter.intersects('id', ids),
    limit: objs.length
  }).objs;
  objs.forEach(function(srcObj) {
    job.corpusSource.pathsToDocuments.forEach(function(path) {
      //TODO: pre-determine which are array fields to avoid this check
      var fieldValue = srcObj.at(path);
      if (fieldValue != null && fieldValue.length > 0) {
        if (typeof fieldValue == "string") {
          documentsBatch.push(fieldValue);
        } else if (fieldValue.isArray()) {
          documentsBatch = documentsBatch.concat(fieldValue);
        }
      }
    });
  });
  var batchResult;
  if (documentsBatch.length > 0) {
    batchResult = PythonTextProcessor.processDocumentsBatch(documentsBatch, docSummarySpec, preProcessingSpecs,
                                                            job.corpusProcessSpec.keepRawCounts);
    batchResult["~~CorpusSourceDocCount~~"] = documentsBatch.length;
  } else {
    batchResult = new C3.typesys.Mapp(new C3.typesys.MappType(C3.typesys.PrimitiveType.Str,
                                                              C3.typesys.PrimitiveType.Int));
  }
  return batchResult;
}

function reduce(outKey, interValues, job) {
  var count = 0;
  interValues.forEach( function(c) { count += c; } );
  return C3.typesys.Arry.fromPrimitive("int", [count]);
}
