/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

var filename = "test_corpusLanguageModel";

//TICKET TO FIX AND ENABLE THIS TEST: BUILD-2231
xdescribe(filename, function() {
  var DAY_1 = "2017-05-01";
  var DAY_2 = "2017-05-02";

  var ctx, helicopterIds, engineIds, workLogIds, commentIds, preProcessSpec, jobIds = [], modelIds = [];

  it("setup", function() {
	  ctx = TestApi.createContext(filename, null, [AnalyticsQueue]);

    helicopterIds = TestApi.upsertBatchEntity(ctx, "Helicopter", [{}, {}, {}, {}]);

    engineIds = TestApi.upsertBatchEntity(ctx, "HeliEngine", [
        {helicopter: helicopterIds[0]},
        {helicopter: helicopterIds[0]},
        {helicopter: helicopterIds[1]},
        {helicopter: helicopterIds[2]}
    ]);

    workLogIds = TestApi.upsertBatchEntity(ctx, "WorkLog", [
        {dateOfWork: DAY_1, part: engineIds[0], workerNotes: "The !$ engine is smokey"},    // helicopterIds[0]
        {dateOfWork: DAY_2, part: engineIds[0], workerNotes: "The avocado %$^is smokey"},   // helicopterIds[0]
        {dateOfWork: DAY_2, part: engineIds[1], workerNotes: "The monkey, is smokey"},      // helicopterIds[0]
        {dateOfWork: DAY_2, part: engineIds[1], workerNotes: "fish is blue"},      // helicopterIds[0]
        {dateOfWork: DAY_2, part: engineIds[2], workerNotes: "The banana is %&ripe"},       // helicopterIds[1]
        {dateOfWork: DAY_2, part: engineIds[3], workerNotes: "yes length banana is for the %&ripe"} // helicopterIds[2]
    ]);

    commentIds = TestApi.upsertBatchEntity(ctx, "PilotComment", [
        {date: DAY_1, part: engineIds[0], comment: "Flying is fun!"},    // helicopterIds[0]
        {date: DAY_2, part: engineIds[0], comment: "Is aviation (a.k.a. 'flying') entertaining?"},   // helicopterIds[0]
        {date: DAY_2, part: engineIds[1], comment: "The length of this comment is fixed"},      // helicopterIds[0]
        {date: DAY_2, part: engineIds[2], comment: "One fish, two fish"},       // helicopterIds[1]
        {date: DAY_2, part: engineIds[3], comment: "RED FISH!!! BLUE FISH!!!"} // helicopterIds[2]
    ]);

    preProcessSpec = PythonTextPreProcessSpec.make({
      "steps": [
          {
              "type": "PythonRemovePunctuationSpec"
          },
          {
              "type": "PythonToLowerSpec"
          },
          {
              "type": "PythonRemoveStopWordsForLocaleSpec",
              "locale": {
                  "id": "en_US",
                  "language": "en"
              }
          },
          {
              "type": "PythonReplaceWordsSpec",
              "glossary": {
                  "smokey": "smoke",
                  "fish": "cat"
              }
          }
      ]
    });

    TestApi.waitForSetup(ctx, null, 1, 30);
  });

  it("tests a very basic n-gram model", function() {
    //inner setup
    var corpusSources = [
      CorpusSource.make({srcType: TypeRef.make({typeName: "Helicopter"}),
                         pathsToDocuments: ["engines.workLogs.workerNotes"], estimatedDocsPerSourceObj: 5}),
      CorpusSource.make({srcType: TypeRef.make({typeName: "PilotComment"}),
                         pathsToDocuments: ["comment"], estimatedDocsPerSourceObj: 1})
    ];
    var docSummarySpec = NGramCountsSpec.make({minNGramLength: 1, maxNGramLength: 2});
    var corpusProcessSpec = NGramCountProcessSpec.make({preProcessSpec: preProcessSpec,
                                                        docSummarySpec: docSummarySpec});
    var model = NGramCountModel.make({corpusSources: corpusSources, corpusProcessSpec: corpusProcessSpec,
                                      description: "test", keepRawCounts: true});
    model = model.processCorpus();
    //Register for teardown
    modelIds.push(model.id);
    jobIds = jobIds.concat(_.pluck(model.processingJobs, "id"));

    TestApi.waitForSetup(ctx, null, 3, 240);  // TODO investigate why so slow, should fix! If fails again, disable test

    expect(model.allJobsFinished()).toBe(true);

    //check feature map
    var featureMap = model.getFeatureMap();
    expect(featureMap.the).toBeUndefined();
    //exhaustive
    var expectedCounts = {"avocado": 1, "avocado smoke": 1, "banana": 2, "banana ripe": 2, "blue": 2,
      "cat": 5, "cat blue": 2, "engine": 1, "engine smoke": 1, "length": 2, "length banana": 1, "monkey": 1,
      "monkey smoke": 1, "ripe": 2, "smoke": 3, "yes": 1, "yes length": 1, "aka": 1, "aka flying": 1,
      "aviation": 1, "aviation aka": 1, "blue cat": 1, "cat two": 1, "comment": 1, "comment fixed": 1,
      "entertaining": 1, "flying": 2, "flying entertaining": 1, "flying fun": 1, "fun": 1,
      "length comment": 1, "one": 1, "one cat": 1, "red": 1, "red cat": 1, "fixed": 1, "two": 1,
      "two cat": 1
    };
    expect(featureMap).toEqual(expectedCounts);
  });

  it("teardown", function() {
    TestApi.removeEntities(ctx, engineIds); // TODO investigate why we need to tear this down separately
    CorpusSourceProcessingJob.removeAll(Filter.intersects("id", jobIds));
    NGramCountModel.removeAll(Filter.intersects("id", modelIds));

    TestApi.teardown(ctx);
    expect(ctx.numObjects()).toEqual(0);
  });
});
