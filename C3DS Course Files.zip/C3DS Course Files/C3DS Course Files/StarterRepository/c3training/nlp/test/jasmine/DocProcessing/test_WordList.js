/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

var filename = "test_WordList";

describe(filename, function () {
  function expectShortWordList(wordList) {
    expect(wordList.words).toContain("my");
    expect(wordList.words).toContain("short");
    expect(wordList.words).toContain("word");
    expect(wordList.words).toContain("list");
    expect(wordList.words).not.toContain("cow");
    expect(wordList.name).toEqual("short");
  }

  it("short word list matches using fromWordString", function () {
    expectShortWordList(WordList.fromWordString("short", "my short word list"));
  });

  it("short word list matches using fromWordList", function () {
    expectShortWordList(WordList.fromWordList("short", ["my", "short", "word", "list"]));
  });
});
