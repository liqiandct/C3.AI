/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

var filename = "test_PreProcessableDoc";

describe(filename, function () {
  beforeAll(function() {
    this.ctx = TestApi.createContext(filename, null, [AnalyticsQueue]);

    var helicopterIds = TestApi.upsertBatchEntity(this.ctx, "Helicopter", [{}, {}, {}, {}]);

    this.engineIds = TestApi.upsertBatchEntity(this.ctx, "HeliEngine", [
      {helicopter: helicopterIds[0]},
      {helicopter: helicopterIds[0]},
      {helicopter: helicopterIds[1]},
      {helicopter: helicopterIds[2]}
    ]);

    this.workLogs = [
      {part: this.engineIds[0], workerNotes: "the !$ engine is smokey"},  // helicopterIds[0]
      {part: this.engineIds[0], workerNotes: "the avocado %$^is smokey"}, // helicopterIds[0]
      {part: this.engineIds[1], workerNotes: "the monkey, is smokey"},    // helicopterIds[0]
      {part: this.engineIds[2], workerNotes: "the banana is %&ripe"},     // helicopterIds[1]
      {part: this.engineIds[3], workerNotes: "yes banana is %&ripe"}      // helicopterIds[2]
    ];

    this.workLogIds = TestApi.upsertBatchEntity(this.ctx, "WorkLog", this.workLogs);

    var self = this;
    _.each(this.workLogs, function(workLog, index) { workLog.id = self.workLogIds[index]; });

    this.preProcessSpec = PythonTextPreProcessSpec.make({
      "steps": [
        PythonRemovePunctuationSpec.make({}),
        PythonRemoveStopWordsForLocaleSpec.make({
          "locale": {
            "id": "en_US",
            "language": "en"
          }
        }),
        PythonReplaceWordsSpec.make({
          "glossary": {
            "smokey": "smoke"
          }
        })
      ]
    });

    TestApi.waitForSetup(this.ctx, null, 1, 30);
  });

  beforeEach(function() {
    if (this.ctx) {
      //Make sure that pre-processing is not persisted across tests.
      TestApi.removeEntitiesByFilter(this.ctx, Filter.intersects("id", this.workLogIds), WorkLog);
      TestApi.upsertBatchEntity(this.ctx, "WorkLog", this.workLogs);
    }
  });

  function fetchAndCheckLogs(workLogs, preProcessSpecLocal, expectedProcessedText) {
    var workLogIds = _.pluck(workLogs, "id");
    var processedLogs = WorkLog.fetch({
      include: "id, text, preProcessedText, workerNotes",
      filter: Filter.intersects("id", workLogIds)
    }).objs;

    _.each(workLogs, function(rawLog, index) {
      var processedLog = _.findWhere(processedLogs, {id: rawLog.id});
      expect(processedLog.workerNotes).toEqual(rawLog.workerNotes);

      var preProcessedText = processedLog.preProcessedText;
      expect(preProcessedText.processedText).toEqual(expectedProcessedText[index]);
      expect(preProcessedText.preProcessSpec.id).toEqual(preProcessSpecLocal.id);
    });
  }

  function processAndValidate(self, preProcessSpecLocal, expectedProcessedText) {
    if (preProcessSpecLocal.id) {
      TestApi.removeEntity(self.ctx, preProcessSpecLocal.id);
    }
    // work-around for the fact that the anyof is not handled cleanly by upsertEntity
    var persisted = TestApi.upsertEntity(self.ctx, "PythonTextPreProcessSpec", {
      "steps": [PythonRemovePunctuationSpec.make({})]
    });
    preProcessSpecLocal = preProcessSpecLocal.putField("id", persisted.id).upsert();
    var job = WorkLog.preProcessDocs(preProcessSpecLocal);
    TestApi.waitForJob(self.ctx, job, 1, 30);
    expect(job.hasErrors()).toEqual(false);
    fetchAndCheckLogs(self.workLogs, preProcessSpecLocal, expectedProcessedText);
  }

  it("Should pre-process and persist text even if text is empty", function() {
    var expectedText = [undefined, "avocado", "monkey", "banana ripe", "yes banana ripe"];
    var spec = PythonTextPreProcessSpec.make({
      "steps": [
        PythonRemovePunctuationSpec.make({}),
        PythonRemoveStopWordsForLocaleSpec.make({
          "locale": {
            "id": "en_US",
            "language": "en"
          }
        }),
        PythonRemoveWordsSpec.make({
          "blackList": ["engine", "smokey"]
        })
      ]
    });
    processAndValidate(this, spec, expectedText);
  });

  it("Should pre-process and persist text", function() {
    var expectedText = ["engine smoke", "avocado smoke", "monkey smoke", "banana ripe", "yes banana ripe"];
    processAndValidate(this, this.preProcessSpec, expectedText);
  });

  it("Should fetch text in pre-process if necessary", function() {
    // test case was created to cover issue https://c3energy.atlassian.net/browse/DATA-2221
    var expectedText = ["engine smoke", "avocado smoke", "monkey smoke", "banana ripe", "yes banana ripe"];

    var preProcessSpecLocal = this.preProcessSpec;

    if (preProcessSpecLocal.id) {
      TestApi.removeEntity(this.ctx, preProcessSpecLocal.id);
    }
    // work-around for the fact that the anyof is not handled cleanly by upsertEntity
    var persisted = TestApi.upsertEntity(this.ctx, "PythonTextPreProcessSpec", {
      "steps": [PythonRemovePunctuationSpec.make({})]
    });
    preProcessSpecLocal = preProcessSpecLocal.putField("id", persisted.id).upsert();

    var job = DocPreProcessingJob.make({
      include: "id",
      targetType: WorkLog,
      preProcessSpec: preProcessSpecLocal
    });
    job = job.upsert();
    job.start();

    TestApi.waitForJob(this.ctx, job, 1, 30);
    expect(job.hasErrors()).toEqual(false);
    fetchAndCheckLogs(this.workLogs, preProcessSpecLocal, expectedText);
  });

  it("Should process multiple times", function() {
    var expectedText = ["engine smoke", "avocado smoke", "monkey smoke", "banana ripe", "yes banana ripe"];
    processAndValidate(this, this.preProcessSpec, expectedText);
    var preProcessSpec2 = PythonTextPreProcessSpec.make({
      "steps": [
        PythonReplaceWordsSpec.make({
          "glossary": {
            "banana": "fish"
          }
        })
      ]
    });
    expectedText = [
      "the !$ engine is smokey", "the avocado %$^is smokey", "the monkey, is smokey", "the fish is %&ripe",
      "yes fish is %&ripe"
    ];
    processAndValidate(this, preProcessSpec2, expectedText);
  });

  it("Should not change documents with no text", function() {
    var newWorkLog = TestApi.upsertEntity(this.ctx, "WorkLog", {part: this.engineIds[2]});
    var expectedText = ["engine smoke", "avocado smoke", "monkey smoke", "banana ripe", "yes banana ripe"];
    processAndValidate(this, this.preProcessSpec, expectedText);
    newWorkLog = WorkLog.fetch({filter: Filter.eq("id", newWorkLog.id), include: "id, text, preProcessedText"}).objs[0];
    expect(newWorkLog.preProcessedText).toBeUndefined();
    expect(newWorkLog.text).toBeUndefined();
    TestApi.removeEntity(this.ctx, newWorkLog.id);
  });

  it("teardown", function() {
    TestApi.removeEntities(this.ctx, this.engineIds); // TODO investigate why we need to tear this down separately
    TestApi.teardown(this.ctx);
    expect(this.ctx.numObjects()).toEqual(0);
  });
});
