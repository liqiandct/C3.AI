/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

var filename = "test_PythonTextProcessor";

describe(filename, function(){
  it("should create from strings", function() {
    expect(PythonTextProcessor.fromString("To be or not to Be!").words[5]).toBe("Be!");
    expect(PythonTextProcessor.fromString("To be or not to Be!", "\\s+").words[5]).toBe("Be!");
    expect(PythonTextProcessor.fromString("To be or not to Be!", "o").words[1]).toBe(" be ");
    expect(PythonTextProcessor.fromString("To be or 123 not to Be!", "[0-9]+").words[1]).toBe(" not to Be!");
  });

  it("should return strings", function(){
    var wp = PythonTextProcessor.fromString("c3 energy");
    expect(wp.toString(null)).toBe("c3 energy");
    expect(wp.toString("-")).toBe("c3-energy");
  });

  it("should remove punctuation correctly", function() {
    var wp = PythonTextProcessor.fromString("Many words, such comma: period!");
    expect(wp.removePunctuation().toString()).toBe("Many words such comma period");
  });

  it("should lower case correctly", function() {
    var wp = PythonTextProcessor.fromString("STrangE CaSe");
    expect(wp.toLowerCase().toString()).toBe("strange case");
  });

  it("should remove characters correctly", function() {
    var wp = PythonTextProcessor.fromString("No 12number3 allo0wed9");
    expect(wp.removeCharacters("1234567890").toString()).toBe("No number allowed");
  });

  it("should drop word lengths(inclusively)", function() {
    var wp = PythonTextProcessor.fromString("1 22 55555 666666");
    expect(wp.dropWordLengths(2, 5).words.length).toBe(2);
    expect(wp.dropWordLengths(2, null).words.length).toBe(3);
    expect(wp.dropWordLengths(null, 5).words.length).toBe(3);
  });

  it("should replace words correctly", function() {
    var wp = PythonTextProcessor.fromString("If I try will I succeed?");
    var m = {"I": "you", "will": "must", "absent": "present"};
    expect(wp.replaceWords(m).toString()).toBe("If you try must you succeed?");
  });

  it("should remove words correctly", function() {
    var wp = PythonTextProcessor.fromString("so many bad bad words are being said");
    expect(wp.removeWords(["bad", "absent", "so"]).toString()).toBe("many words are being said");
    expect(wp.removeStopWordsForLocale({id: "en", language: "en"}).toString()).toBe("many bad bad words said");

  });

  it("should remove words by regex correctly", function() {
    var wp = PythonTextProcessor.fromString("Really remove these silly adverbs");
    expect(wp.removeByRegex("[A-Za-z]*ly").toString()).toBe("remove these adverbs");
  });

  it("should replace words by regex correctly", function() {
    var wp = PythonTextProcessor.fromString("Here is my number: +1 (650) 123-4567.");
    wp = wp.replaceByRegex("[0-9]{4}", "xxxx").replaceByRegex("[0-9]{3}", "xxx");
    expect(wp.toString()).toBe("Here is my number: +1 (xxx) xxx-xxxx.");
  });

  it("should throw errors for unsupported languages", function() {
    var wp = PythonTextProcessor.fromString("fantasy movies are awesome");
    expect(function() { wp.removeStopWordsForLocale({id: "mu", language: "elfin"}); }).toThrow();
    expect(function() { wp.stemForLocale({id: "mu", language: "dothraki"}); }).toThrow();
  });

  it("should create and count ngrams correctly", function() {
    var wp = PythonTextProcessor.fromString("far far away in a far away long time ago");
    expect(wp.nGrams(3).length).toBe(8);
    expect(wp.nGrams(10).length).toBe(1);
    expect(wp.nGrams(2)[1]).toEqual("far away");
    expect(wp.pGramsCounts(2, 10)).toEqual(jasmine.objectContaining({
      "far away": 2,
      "far far away in a far away long": 1,
      "far far away in a far away long time ago": 1,
      "far far away in a far away long time": 1,
      "far away in a far away long time ago": 1
    }));
    expect(function() { wp.nGrams(-1); }).toThrow();
  });

  it("should count words and ngrams correctly", function() {
    var wp = PythonTextProcessor.fromString("natural language tool kit is a natural choice for any natural language projects");
    expect(wp.nGramCounts(2)["natural language"]).toBe(2);
    expect(wp.wordCounts().natural).toBe(3);
  });

  it("should lemmatize correctly", function() {
    var wp = PythonTextProcessor.fromString("and then the wolves came");
    expect(wp.lemmatize().toString()).toBe("and then the wolf come");
  });

  it("should stem correctly", function() {
    var wp = PythonTextProcessor.fromString("having stemmed the stemming stems they quickly left");
    var l = Locale.make({language: "en"});
    expect(wp.stemForLocale(l).toString()).toBe("have stem the stem stem they quick left");
  });

  it("should process many steps correctly", function() {
    var locale = {id: "en_US", language:"en"};
    var steps = [
      PythonToLowerSpec.make(),
      PythonDropWordLengthsSpec.make({minLength: 2, maxLength: 9}),
      PythonRemovePunctuationSpec.make(),
      PythonCorrectSpellingSpec.make({pythonSpellChecker: PythonSpellChecker.make({wordCounts: {greaz: 1e8}, locale: locale})}),
      PythonLemmatizeSpec.make(),
      PythonRemoveStopWordsForLocaleSpec.make({locale: locale}),
      PythonStemForLocaleSpec.make({locale: locale}),
      PythonRemoveCharactersSpec.make({blackList: "aeiou"}),
      PythonReplaceWordsSpec.make({glossary: {r: "l"}}),
      PythonRemoveWordsSpec.make({blackList:["l", "qck"]})
    ];
    var originalString = "we are having a GREAP looooooong TIME fznding ore, and t is quickly drinking ale!";
    var wp = PythonTextProcessor.fromString(originalString);
    /**
     * we are having a GREAP looooooong TIME fznding ore, and t is quickly drinking ale!
     * we are having a greap looooooong time fznding ore, and t is quickly drinking ale! (PythonToLowerSpec)
     * we are having greap time fznding ore, and is quickly drinking ale! (PythonDropWordLengthsSpec)
     * we are having greap time fznding ore and is quickly drinking ale (PythonRemovePunctuationSpec)
     * we are having greaz time finding ore and is quickly drinking ale (PythonCorrectSpellingSpec)
     * we be have greaz time find ore and be quickly drink ale (PythonLemmatizeSpec)
     * greaz time find ore quickly drink ale (PythonRemoveStopWordsForLocaleSpec)
     * greaz time find ore quick drink ale (PythonStemForLocaleSpec)
     * grz tm fnd r qck drnk l (PythonRemoveCharactersSpec)
     * grz tm fnd l qck drnk l (PythonReplaceWordsSpec)
     * grz tm fnd drnk (PythonRemoveWordsSpec)
     */
    expect(wp.preProcess(PythonTextPreProcessSpec.make({steps: steps})).toString()).toBe("grz tm fnd drnk");
    expect(wp.toString()).toBe(originalString);
  });

  it("should not make lowercase without lowercase step", function() {
    var steps = [
      PythonDropWordLengthsSpec.make({minLength: 2}),
    ];
    var wp = PythonTextProcessor.fromString("we are having a GREAT TIME finding ore, and t is quickly drinking ale!");
    expect(wp.preProcess(PythonTextPreProcessSpec.make({steps: steps})).toString()).toBe("we are having GREAT TIME finding ore, and is quickly drinking ale!");
  });

  it("should make lowercase with lowercase step", function() {
    var steps = [
      PythonToLowerSpec.make(),
      PythonDropWordLengthsSpec.make({minLength: 2, maxLength: null}),
    ];
    var wp = PythonTextProcessor.fromString("we are having a GREAT TIME finding ore, and t is quickly drinking ale!");
    expect(wp.preProcess(PythonTextPreProcessSpec.make({steps: steps})).toString()).toBe("we are having great time finding ore, and is quickly drinking ale!");
  });
});
