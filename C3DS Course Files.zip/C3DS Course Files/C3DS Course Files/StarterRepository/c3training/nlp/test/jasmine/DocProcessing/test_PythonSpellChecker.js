/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

var filename = 'test_pythonSpellChecker';

describe(filename, function() {
    function copyOwnProperties(obj) {
       // Returns a shallow copy of the object with only its own properties.
       // Useful if you need to test C3.typesys.Map contents.
       var res = {};
       for (var key in obj) {
          if (obj.hasOwnProperty(key)) {
            res[key] = obj[key];
          }
       }
       return res;
    }

    it('should correct spelling for english', function() {
        var sc = PythonSpellChecker.make({
            'locale': {language:'en'},
        });
        var res = sc.correctWords(['helples', 'helples', 'spellin', 'often', 'difficut']);
        expect(res.words).toEqual(['helpless', 'helpless', 'spelling', 'often', 'difficult']);
        expect(copyOwnProperties(res.misspellingsCounts)).toEqual({helples: 2, spellin: 1, difficut: 1});
    });

    it('should correct spelling for english with custom words', function() {
        var sc = PythonSpellChecker.make({
            locale: {language:'en'},
            wordCounts: {
              universitiesa: 6,   // Because universities has frequency 7 in TextBlob, it will choose this instead of universitiesz
              unintelligiblea: 8 // Because unintelligible has frequency 7 in TextBlob, it will choose unintelligiblez instead
            }
        });
        var res = sc.correctWords(['helples', 'universitiesz', 'helples', 'unintelligiblez', 'spellin', 'often', 'difficut']);
        expect(res.words).toEqual(['helpless', 'universities', 'helpless', 'unintelligiblea', 'spelling', 'often', 'difficult']);
        expect(copyOwnProperties(res.misspellingsCounts)).toEqual({helples: 2, universitiesz: 1, unintelligiblez: 1, spellin: 1, difficut: 1});
    });

    it('should throw an exception when given an unsupported language', function() {
        var exception;
        var sc = PythonSpellChecker.make({
           locale: {language:'esperanto'},
        });
        expect(function () {
           sc.validWord('c3');
        }).toThrowError(/supported/);
    });

    it('should remove misspellings if set to true', function() {
        var sc = PythonSpellChecker.make({
           wordCounts: {
              hello: 1,
              my: 1,
              is: 1,
              specwatis: 1
           },
        });
        var res = sc.correctWords(['hello', 'my', 'namr', 'namr', 'foo', 'invalid', 'word', 'is', 'specwatis'], true);
        expect(res.words).toEqual(['hello', 'my', 'is', 'specwatis']);
        expect(copyOwnProperties(res.misspellingsCounts)).toEqual({namr: 2, foo: 1, invalid: 1, word: 1});
    });

    it('should have basic working APIs', function() {
        var sc = PythonSpellChecker.make({
           wordCounts: {
              hello: 1,
              my: 2,
              mp: 1,
              is: 1,
              name: 1,
              specwatis: 1
           },
        });

        expect(sc.correctWord('helo')).toEqual('hello');
        expect(sc.correctWord('specwati')).toEqual('specwatis');
        expect(sc.correctWord('specwat')).toEqual('specwatis');

        var res = sc.correctWords(['hello', 'ma', 'namr', 'namre', 'foo', 'foo', 'invalid', 'is', 'specwatis']);
        expect(res.words).toEqual(['hello', 'my', 'name', 'name', 'foo', 'foo', 'invalid', 'is', 'specwatis']);
        expect(copyOwnProperties(res.misspellingsCounts)).toEqual({ma: 1, namr: 1, namre: 1, foo: 2, invalid: 1});

        expect(sc.validWord('hello')).toBe(true);
        expect(sc.validWord('helo')).toBe(false);

        expect(sc.wordSuggestions('ma')).toEqual(['my', 'mp']);
        expect(sc.wordSuggestions('ma', 10)).toEqual(['my', 'mp']);
        expect(sc.wordSuggestions('ma', 1)).toEqual(['my']);
        expect(sc.wordSuggestions('kw2ejlcsjjdfssfd', 10)).toEqual(['kw2ejlcsjjdfssfd']);
    });
});
