/*
 * Copyright 2009-2019 C3 (www.c3.ai). All Rights Reserved.
 * This material, including without limitation any software, is the confidential trade secret and proprietary
 * information of C3 and its licensors. Reproduction, use and/or distribution of this material in any form is
 * strictly prohibited except as set forth in a written license agreement with C3 and/or its authorized distributors.
 * This material may be covered by one or more patents or pending patent applications.
 */

var filename = "test_NLPintegration";

describe(filename, function() {
  var DAY_1 = "2017-05-01";
  var DAY_2 = "2017-05-02";
  var DAY_3 = "2017-05-03";
  var DAY_4 = "2017-05-04";

  var ctx, helicopterIds, engineIds, workLogIds, preProcessSpec;

  it("setup", function() {
    ctx = TestApi.createContext(filename, null, [AnalyticsQueue]);

    helicopterIds = TestApi.upsertBatchEntity(ctx, "Helicopter", [{}, {}, {}, {}]);

    engineIds = TestApi.upsertBatchEntity(ctx, "HeliEngine", [
        {helicopter: helicopterIds[0]},
        {helicopter: helicopterIds[0]},
        {helicopter: helicopterIds[1]},
        {helicopter: helicopterIds[2]}
    ]);

    workLogIds = TestApi.upsertBatchEntity(ctx, "WorkLog", [
        {dateOfWork: DAY_1, part: engineIds[0], workerNotes: "The !$ engine is smokey"},    // helicopterIds[0]
        {dateOfWork: DAY_2, part: engineIds[0], workerNotes: "The avocado %$^is smokey"},   // helicopterIds[0]
        {dateOfWork: DAY_2, part: engineIds[1], workerNotes: "The monkey, is smokey"},      // helicopterIds[0]
        {dateOfWork: DAY_2, part: engineIds[2], workerNotes: "The banana is %&ripe"},       // helicopterIds[1]
        {dateOfWork: DAY_2, part: engineIds[3], workerNotes: "yes banana length is %&ripe"} // helicopterIds[2]
    ]);

    preProcessSpec = PythonTextPreProcessSpec.make({
      "steps": [
        PythonRemovePunctuationSpec.make({}),
        PythonRemoveStopWordsForLocaleSpec.make({
          "locale": {
            "id": "en_US",
            "language": "en"
          }
        }),
        PythonReplaceWordsSpec.make({
          "glossary": {
            "smokey": "smoke"
          }
        })
      ]
    });

    TestApi.waitForSetup(ctx, null, 1, 30);
  });

  function getTimeseriesMapValues(timeSeries) {
    return _.pluck(timeSeries.data(), 'value');
  }

  function expectFeatureCountSeriesAndExtractFeature(helicopter, tsEvalSpec, expectedValues) {
    var processSpec = CorpusProcessSpec.make({preProcessSpec: preProcessSpec, docSummarySpec: WordCountSpec.make()});
    expectFeatureCountSeriesWithProcessSpec(helicopter, tsEvalSpec, expectedValues, processSpec);
  }

  function expectFeatureCountSeriesWithProcessSpec(helicopter, tsEvalSpec, expectedValues, processSpec) {
    var docSpecs = [TimedDocumentSpec.make({pathToDocument: "engines.workLogs", textFields: ["workerNotes"], datetimeField: "dateOfWork"})];
    var featureCountSeries = Helicopter.featureCountSeries(helicopter, tsEvalSpec, SimpleMetric.get("FeatureCountSeries_NLEvaluatable"), processSpec, docSpecs);
    var actualValues = getTimeseriesMapValues(featureCountSeries);
    expect(actualValues).toEqual(expectedValues);  // Check that the maps are equivalent for all features
    for (var key in expectedValues[0]) {
      var actual = _.map(NLFunctionLibrary.extractFeature(featureCountSeries, key).data());
      var expected = _.map(expectedValues, function(x) { return x[key] ? x[key] : 0; });
      expect(actual).toEqual(expected);  // Check that the lists for a single feature are equivalent
    }
  }

  it("works using NGramProcessSpec for two days", function() {
    expectFeatureCountSeriesWithProcessSpec(
      Helicopter.get(helicopterIds[0]),
      TSEvalSpec.make({ids: [helicopterIds[0]], start: DAY_1, end: DAY_3, interval: "DAY"}),
      [{"engine":1,"The":1,"smoke":1,"engine smoke":1,"The engine":1}, {"monkey":1,"smoke":2,"avocado":1,"The":2,"The avocado":1,"monkey smoke":1,"avocado smoke":1,"The monkey":1}],
      // TODO this test will pass if we set maxNGramLength below to 1, it only uses the docSummarySpec. Remove?
      NGramProcessSpec.make({minNGramLength: 1, maxNGramLength: 2, preProcessSpec: preProcessSpec, docSummarySpec: NGramCountsSpec.make({minNGramLength: 1, maxNGramLength: 2, preProcessSpec: preProcessSpec})})
    );
  });

  it("featureCountSeries for DAY_1", function() {
    expectFeatureCountSeriesAndExtractFeature(
      Helicopter.get(helicopterIds[0]),
      TSEvalSpec.make({ids: [helicopterIds[0]], start: DAY_1, end: DAY_2, interval: "DAY"}),
      [{"engine":1,"The":1,"smoke":1}]
    );
  });

  it("featureCountSeries for DAY_2", function() {
    expectFeatureCountSeriesAndExtractFeature(
      Helicopter.get(helicopterIds[0]),
      TSEvalSpec.make({ids: [helicopterIds[0]], start: DAY_2, end: DAY_3, interval: "DAY"}),
      [{"monkey":1,"smoke":2,"avocado":1,"The":2}]
    );
  });

  it("featureCountSeries for two days", function() {
    expectFeatureCountSeriesAndExtractFeature(
      Helicopter.get(helicopterIds[0]),
      TSEvalSpec.make({ids: [helicopterIds[0]], start: DAY_1, end: DAY_3, interval: "DAY"}),
      [{"engine":1,"The":1,"smoke":1}, {"monkey":1,"smoke":2,"avocado":1,"The":2}]
    );
  });

  it("featureCountSeries for three days", function() {
    expectFeatureCountSeriesAndExtractFeature(
      Helicopter.get(helicopterIds[0]),
      TSEvalSpec.make({ids: [helicopterIds[0]], start: DAY_1, end: DAY_4, interval: "DAY"}),
      [{"engine":1,"The":1,"smoke":1}, {"monkey":1,"smoke":2,"avocado":1,"The":2}, {}]
    );
  });

  it("featureCountSeries for helicopter 1", function() {
    expectFeatureCountSeriesAndExtractFeature(
      Helicopter.get(helicopterIds[1]),
      TSEvalSpec.make({ids: [helicopterIds[0]], start: DAY_1, end: DAY_4, interval: "DAY"}),
      [{}, {"The": 1, "banana": 1, "ripe": 1}, {}]
    );
  });

  it("featureCountSeries for helicopter 2", function() {
    expectFeatureCountSeriesAndExtractFeature(
      Helicopter.get(helicopterIds[2]),
      TSEvalSpec.make({ids: [helicopterIds[0]], start: DAY_1, end: DAY_4, interval: "DAY"}),
      [{}, {"yes": 1, "banana": 1, "length": 1, "ripe": 1}, {}]
    );
  });

  it("can process tfidf for entire corpus", function() {
    // TODO
  });

  it("teardown", function() {
    TestApi.removeEntities(ctx, engineIds); // TODO investigate why we need to tear this down separately
    TestApi.teardown(ctx);
    expect(ctx.numObjects()).toEqual(0);
  });
});
