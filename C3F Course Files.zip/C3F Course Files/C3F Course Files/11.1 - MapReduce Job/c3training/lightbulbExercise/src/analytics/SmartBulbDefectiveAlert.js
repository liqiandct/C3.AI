/*
* Copyright 2009-2020 C3, Inc. All Rights Reserved.
* This material, including without limitation any software, is the confidential trade secret
* and proprietary information of C3 and its licensors. Reproduction, use and/or distribution
* of this material in any form is strictly prohibited except as set forth in a written
* license agreement with C3 and/or its authorized distributors.
* This product may be covered by one or more U.S. patents or pending patent applications.
~*/

var log = C3.logger("SmartBulbDefectiveAlert");

var FAILED = 1;

function process(input) {
  // input comes from the SmartBulbDefectiveInput, passed in the first Analytic parameter in SmartBulbDefectiveAlert.c3typ.
  // The defective field was declared in SmartBulbDefectiveInput.c3typ and is used here.
  // The .data() and .dates() methods are available on SmartBulbDefective and called here to instantiate our variables.
  var data  = input.defective.data(),
      dates = input.defective.dates();
  for (var i = 0; i < data.length; i++) {
    // If the timeseries at a given point is 1, which means that the SmartBulb has failed, then we need to create a new SmartBulbEvent instance to log the event.
    // By using input.source, we are using the source SmartBulb referenced by our input object, SmartBulbDefectiveInput.
    // Additionally, we are filling in the values for the other SmartBulbEvent fields.
    // Lastly, we use the .make() method and let the Analytic handle creating & persisting/updating the  object
    if (data.at(i) == FAILED) {
      return SmartBulbEvent.make({
        smartBulb: input.source,
        eventCode: "DEFECTIVE",
        eventType: "Health",
        start: dates.at(i),
        end: dates.at(i+1)
      });
    }
  }
}
